--
-- PostgreSQL database dump
--

\restrict hhgK6L96sqVL92fNkbl5C9EFUPWCfoVHQQXc4lxMqSg01LPvDOGyKZADXOcDOTh

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-12 18:23:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 138599)
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(255) NOT NULL,
    guard_name character varying(50) DEFAULT 'web'::character varying NOT NULL,
    category character varying(100) NOT NULL,
    module character varying(100),
    priority smallint DEFAULT '0'::smallint NOT NULL,
    display_order smallint DEFAULT '0'::smallint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    requires_confirmation boolean DEFAULT false NOT NULL,
    conditions json,
    dependencies json,
    created_by uuid,
    updated_by uuid,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT permissions_action_check CHECK (((action)::text = ANY ((ARRAY['create'::character varying, 'read'::character varying, 'view-details'::character varying, 'update'::character varying, 'delete'::character varying, 'force-delete'::character varying, 'duplicate'::character varying, 'create-version'::character varying, 'activate'::character varying, 'deactivate'::character varying, 'toggle-status'::character varying, 'view-trash'::character varying, 'restore'::character varying, 'view-history'::character varying, 'validate'::character varying, 'reject'::character varying, 'cancel'::character varying, 'pending'::character varying, 'process'::character varying, 'confirm'::character varying, 'complete'::character varying, 'resume'::character varying, 'manage'::character varying, 'assign'::character varying, 'reassign'::character varying, 'withdraw'::character varying, 'suspend'::character varying, 'evaluate'::character varying, 'export'::character varying, 'import'::character varying, 'download'::character varying])::text[])))
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- TOC entry 5109 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.permissions IS 'Table des permissions du système de contrôle d''accès - Module RBAC';


--
-- TOC entry 5110 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.name IS 'Nom affiché de la permission';


--
-- TOC entry 5111 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.slug IS 'Identifiant unique pour la permission';


--
-- TOC entry 5112 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.description IS 'Description détaillée de la permission';


--
-- TOC entry 5113 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.resource; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.resource IS 'Entité/ressource concernée (ex: users, roles, appels_offres)';


--
-- TOC entry 5114 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.action; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.action IS 'Action autorisée sur la ressource';


--
-- TOC entry 5115 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.guard_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.guard_name IS 'Guard utilisé (web, api, etc.)';


--
-- TOC entry 5116 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.category IS 'Catégorie de permission pour groupement';


--
-- TOC entry 5117 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.module; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.module IS 'Module fonctionnel (roles, users, appels_offres, lots, prestataires, factures, paiements)';


--
-- TOC entry 5118 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.priority; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.priority IS 'Priorité de la permission (0-255)';


--
-- TOC entry 5119 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.display_order; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.display_order IS 'Ordre d''affichage dans les listes';


--
-- TOC entry 5120 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.is_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.is_active IS 'Permission active/inactive';


--
-- TOC entry 5121 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.is_system; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.is_system IS 'Permission système (non modifiable)';


--
-- TOC entry 5122 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.requires_confirmation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.requires_confirmation IS 'Action nécessitant une confirmation';


--
-- TOC entry 5123 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.conditions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.conditions IS 'Conditions supplémentaires en JSON';


--
-- TOC entry 5124 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.dependencies; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.dependencies IS 'Permissions dépendantes requises';


--
-- TOC entry 5125 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.created_by IS 'Utilisateur qui a créé la permission';


--
-- TOC entry 5126 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.updated_by IS 'Dernier utilisateur ayant modifié';


--
-- TOC entry 5127 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN permissions.last_used_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.permissions.last_used_at IS 'Dernière utilisation de la permission';


--
-- TOC entry 5103 (class 0 OID 138599)
-- Dependencies: 226
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, slug, description, resource, action, guard_name, category, module, priority, display_order, is_active, is_system, requires_confirmation, conditions, dependencies, created_by, updated_by, last_used_at, created_at, updated_at, deleted_at) FROM stdin;
a0d215b8-628b-4b13-92b5-8a46fe46d30b	Voir la liste des rôles	roles.read	Permet de consulter la liste de tous les rôles du système	roles	read	web	Administration	Rôles	0	1	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-6d7b-43e2-918a-e541f14be81f	Voir les détails d'un rôle	roles.view-details	Permet de consulter les détails complets d'un rôle	roles	view-details	web	Administration	Rôles	0	2	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-6f93-4517-ac04-1eea94051c05	Créer un rôle	roles.create	Permet de créer un nouveau rôle dans le système	roles	create	web	Administration	Rôles	0	3	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-711e-477e-99a4-0c0d5e09a33a	Modifier un rôle	roles.update	Permet de modifier les informations d'un rôle existant	roles	update	web	Administration	Rôles	0	4	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-728b-4d66-aad7-ea77dda5088b	Supprimer un rôle	roles.delete	Permet de supprimer un rôle du système	roles	delete	web	Administration	Rôles	0	5	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-73f7-4cbb-956d-081c54e220f4	Dupliquer un rôle	roles.duplicate	Permet de dupliquer un rôle avec ses permissions	roles	duplicate	web	Administration	Rôles	0	6	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-758e-4e41-a26d-0c8097da93ee	Gérer les permissions d'un rôle	roles.manage	Permet d'attribuer ou retirer des permissions à un rôle	roles	manage	web	Administration	Rôles	0	7	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7757-495c-8ea4-dce35f7ea332	Voir les attributions de permissions	role_permissions.read	Permet de consulter la matrice des permissions par rôle	role_permissions	read	web	Administration	Permissions	0	8	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-78c7-4dfc-8b00-115ae16fb332	Voir les détails d'une attribution	role_permissions.view-details	Permet de consulter les détails d'une attribution de permission	role_permissions	view-details	web	Administration	Permissions	0	9	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7a2a-4021-b8a3-27eaf228fdad	Modifier une attribution	role_permissions.update	Permet de modifier les paramètres d'une attribution (expiration, conditions)	role_permissions	update	web	Administration	Permissions	0	10	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7b9b-4073-b7c4-77ad586b3f5b	Supprimer une attribution	role_permissions.delete	Permet de retirer une permission d'un rôle	role_permissions	delete	web	Administration	Permissions	0	11	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7cf9-4fba-a5f8-9b0817aa6ece	Activer/Désactiver une attribution	role_permissions.toggle-status	Permet d'activer ou désactiver temporairement une attribution	role_permissions	toggle-status	web	Administration	Permissions	0	12	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7e51-4a77-b6f7-42e59aca6f53	Voir l'historique des attributions	role_permissions.view-history	Permet de consulter l'historique des attributions et expirations	role_permissions	view-history	web	Administration	Permissions	0	13	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-7f82-4376-bb30-1834da8b233c	Voir la liste des utilisateurs	users.read	Permet de consulter la liste de tous les utilisateurs	users	read	web	Administration	Utilisateurs	0	14	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-80ad-4c0b-a966-ff26eb60a9cc	Voir les détails d'un utilisateur	users.view-details	Permet de consulter les détails complets d'un utilisateur	users	view-details	web	Administration	Utilisateurs	0	15	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-81c2-4764-85d6-4c337ffb8fd8	Créer un utilisateur	users.create	Permet de créer un nouveau compte utilisateur	users	create	web	Administration	Utilisateurs	0	16	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-82ea-4f66-a411-7aaa512d009c	Modifier un utilisateur	users.update	Permet de modifier les informations d'un utilisateur	users	update	web	Administration	Utilisateurs	0	17	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-83ed-4ff9-9c23-ff9424e22ab4	Supprimer un utilisateur	users.delete	Permet de supprimer un compte utilisateur	users	delete	web	Administration	Utilisateurs	0	18	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-84fd-4a36-b040-ae155711a468	Activer/Désactiver un utilisateur	users.toggle-status	Permet d'activer ou désactiver un compte utilisateur	users	toggle-status	web	Administration	Utilisateurs	0	19	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-85f7-46f6-9612-c1b4e649dc3c	Voir la corbeille des utilisateurs	users.view-trash	Permet de consulter les utilisateurs supprimés	users	view-trash	web	Administration	Utilisateurs	0	20	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8722-4794-a8a3-4e6e463cfde5	Restaurer un utilisateur	users.restore	Permet de restaurer un utilisateur supprimé	users	restore	web	Administration	Utilisateurs	0	21	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8807-4562-b4ea-6ba3dd5f7b0c	Supprimer définitivement un utilisateur	users.force-delete	Permet de supprimer définitivement un utilisateur	users	force-delete	web	Administration	Utilisateurs	0	22	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-88ce-4571-a467-5bcde14c0e19	Voir les types d'appels d'offres	type_appels_offres.read	Permet de consulter la liste des types d'appels d'offres	type_appels_offres	read	web	Appels d'affres	Types d'appels d'offres	0	23	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8a22-4d7e-88fe-a00c5f714721	Voir les détails d'un type	type_appels_offres.view-details	Permet de consulter les détails complets d'un type d'appel d'offres	type_appels_offres	view-details	web	Appels d'affres	Types d'appels d'offres	0	24	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8b7b-4264-8bfa-b1740bfa4425	Créer un type d'appel d'offres	type_appels_offres.create	Permet de créer un nouveau type d'appel d'offres dans le système	type_appels_offres	create	web	Appels d'affres	Types d'appels d'offres	0	25	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8c8d-4baa-b927-01f133c7cbea	Modifier un type d'appel d'offres	type_appels_offres.update	Permet de modifier les informations d'un type d'appel d'offres existant	type_appels_offres	update	web	Appels d'affres	Types d'appels d'offres	0	26	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8d94-40cb-a4aa-d39d39a60ca8	Supprimer un type d'appel d'offres	type_appels_offres.delete	Permet de supprimer un type d'appel d'offres du système	type_appels_offres	delete	web	Appels d'affres	Types d'appels d'offres	0	27	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8eb1-489e-ba88-a12338282bbc	Activer/Désactiver un type	type_appels_offres.toggle-status	Permet d'activer ou désactiver un type d'appel d'offres	type_appels_offres	toggle-status	web	Appels d'affres	Types d'appels d'offres	0	28	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-8fe8-4600-8f13-237c1b72366f	Voir les documents des lots	documents_lots.read	Permet de consulter la liste des documents liés aux lots	documents_lots	read	web	Lots et Évaluations	Documents	0	29	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9105-4d07-a7f7-0bd4086c4c70	Voir les détails d'un document	documents_lots.view-details	Permet de consulter les détails complets d'un document	documents_lots	view-details	web	Lots et Évaluations	Documents	0	30	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9274-4ce9-b467-11a2379dd9b5	Créer un document	documents_lots.create	Permet d'ajouter un nouveau document à un lot	documents_lots	create	web	Lots et Évaluations	Documents	0	31	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9392-466c-b634-15f5af8b5a5d	Modifier un document	documents_lots.update	Permet de modifier les informations d'un document	documents_lots	update	web	Lots et Évaluations	Documents	0	32	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-94b0-4ef3-a209-c2a505520d3f	Supprimer un document	documents_lots.delete	Permet de supprimer un document du système	documents_lots	delete	web	Lots et Évaluations	Documents	0	33	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-95fe-40f7-9196-47a4b9c3e127	Valider un document	documents_lots.validate	Permet de valider un document pour approbation	documents_lots	validate	web	Lots et Évaluations	Documents	0	34	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9729-43c8-914c-570a2727e253	Annuler la validation	documents_lots.cancel	Permet d'annuler la validation d'un document	documents_lots	cancel	web	Lots et Évaluations	Documents	0	35	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-98c9-4f1d-9ff3-370a936d7321	Télécharger un document	documents_lots.download	Permet de télécharger un document	documents_lots	download	web	Lots et Évaluations	Documents	0	36	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-99ed-4c5b-b028-d195d6464467	Voir les types d'appels d'offres	types_appels_offres.read	Permet de consulter la liste des types d'appels d'offres	types_appels_offres	read	web	Appels d'offres	Types AO	0	37	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9b3c-46b4-84c5-3c2893fa139a	Créer un type d'appel d'offres	types_appels_offres.create	Permet de créer un nouveau type d'appel d'offres	types_appels_offres	create	web	Appels d'offres	Types AO	0	38	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9c59-45b2-81c7-defe156c4c84	Voir les détails d'un type	types_appels_offres.view-details	Permet de consulter les détails complets d'un type d'appel d'offres	types_appels_offres	view-details	web	Appels d'offres	Types AO	0	39	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9d62-4b03-b9d8-c52b5e26962a	Modifier un type d'appel d'offres	types_appels_offres.update	Permet de modifier un type d'appel d'offres (crée une nouvelle version)	types_appels_offres	update	web	Appels d'offres	Types AO	0	40	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9e65-44f5-b5c5-3a0daeded018	Supprimer un type d'appel d'offres	types_appels_offres.delete	Permet de supprimer un type d'appel d'offres	types_appels_offres	delete	web	Appels d'offres	Types AO	0	41	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-9f7d-428b-be38-4479a1e2f310	Activer/Désactiver un type	types_appels_offres.toggle-status	Permet d'activer ou désactiver un type d'appel d'offres	types_appels_offres	toggle-status	web	Appels d'offres	Types AO	0	42	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a0cb-44a8-8f0e-f44eb93dd6c9	Voir l'historique des types	types_appels_offres.view-history	Permet de consulter l'historique des versions des types	types_appels_offres	view-history	web	Appels d'offres	Types AO	0	43	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a1ba-48f5-a91d-20eb5a4ad68a	Voir les appels d'offres	appels_offres.read	Permet de consulter la liste des appels d'offres	appels_offres	read	web	Appels d'offres	Appels d'offres	0	44	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a2a1-49cb-be38-f5a0dba71399	Voir les détails d'un appel d'offres	appels_offres.view-details	Permet de consulter les détails complets d'un appel d'offres	appels_offres	view-details	web	Appels d'offres	Appels d'offres	0	45	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a36c-43d4-8f8d-8ea0bd19af50	Créer un appel d'offres	appels_offres.create	Permet de créer un nouvel appel d'offres	appels_offres	create	web	Appels d'offres	Appels d'offres	0	46	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a442-4c22-8bea-a3d0576b2d41	Modifier un appel d'offres	appels_offres.update	Permet de modifier un appel d'offres existant	appels_offres	update	web	Appels d'offres	Appels d'offres	0	47	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a4f2-4677-a877-e564400993ed	Supprimer un appel d'offres	appels_offres.delete	Permet de supprimer un appel d'offres	appels_offres	delete	web	Appels d'offres	Appels d'offres	0	48	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a595-49be-949a-b218f4a540e3	Valider un appel d'offres	appels_offres.validate	Permet de valider un appel d'offres pour publication	appels_offres	validate	web	Appels d'offres	Appels d'offres	0	49	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a63f-4965-ada8-5582bc496db6	Annuler un appel d'offres	appels_offres.cancel	Permet d'annuler un appel d'offres	appels_offres	cancel	web	Appels d'offres	Appels d'offres	0	50	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a6d1-410b-9773-f29f87cf2966	Voir les caractéristiques	caracteristiques_appels_offres.read	Permet de consulter les caractéristiques d'un appel d'offres	caracteristiques_appels_offres	read	web	Appels d'offres	Caractéristiques	0	51	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a769-4d1e-9b9c-aca6f408a88b	Créer des caractéristiques	caracteristiques_appels_offres.create	Permet d'ajouter des caractéristiques à un appel d'offres	caracteristiques_appels_offres	create	web	Appels d'offres	Caractéristiques	0	52	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a7f8-4d46-8ddd-a857450a8daa	Modifier des caractéristiques	caracteristiques_appels_offres.update	Permet de modifier les caractéristiques d'un appel d'offres	caracteristiques_appels_offres	update	web	Appels d'offres	Caractéristiques	0	53	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a882-48d5-a865-2953de5336c9	Supprimer des caractéristiques	caracteristiques_appels_offres.delete	Permet de supprimer des caractéristiques d'un appel d'offres	caracteristiques_appels_offres	delete	web	Appels d'offres	Caractéristiques	0	54	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a908-4ada-9978-9fb192ad70cc	Voir les lots	lots.read	Permet de consulter la liste des lots d'un appel d'offres	lots	read	web	Lots et Évaluations	Lots	0	55	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-a9b9-488e-8efe-acc2a185f416	Voir les détails d'un lot	lots.view-details	Permet de consulter les détails complets d'un lot	lots	view-details	web	Lots et Évaluations	Lots	0	56	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:39	2026-01-12 18:14:39	\N
a0d215b8-aa48-4408-9d40-d19f625f8645	Créer un lot	lots.create	Permet de créer un nouveau lot dans un appel d'offres	lots	create	web	Lots et Évaluations	Lots	0	57	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-aad0-4620-a315-66c575fc94a3	Modifier un lot	lots.update	Permet de modifier un lot existant	lots	update	web	Lots et Évaluations	Lots	0	58	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ab53-4bf2-83e2-d02b619a0428	Supprimer un lot	lots.delete	Permet de supprimer un lot	lots	delete	web	Lots et Évaluations	Lots	0	59	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-abd4-4585-a77f-52081805fb75	Activer/Désactiver un lot	lots.toggle-status	Permet d'activer ou désactiver un lot	lots	toggle-status	web	Lots et Évaluations	Lots	0	60	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ac51-49b4-9e66-77598e732c2f	Voir l'historique des lots	lots.view-history	Permet de consulter l'historique des versions des lots	lots	view-history	web	Lots et Évaluations	Lots	0	61	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-acce-4ea6-9b00-2050e63bb8f1	Dupliquer un lot	lots.duplicate	Permet de dupliquer un lot existant	lots	duplicate	web	Lots et Évaluations	Lots	0	62	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ad83-4e1d-9226-0a2facd2fe79	Voir les critères d'évaluation	criteres_evaluations.read	Permet de consulter les critères d'évaluation d'un lot	criteres_evaluations	read	web	Lots et Évaluations	Critères	0	63	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ae10-41e0-aa7e-c65f06c90396	Créer un critère d'évaluation	criteres_evaluations.create	Permet de créer un nouveau critère d'évaluation	criteres_evaluations	create	web	Lots et Évaluations	Critères	0	64	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ae98-4ce4-82ce-05f21a7b7dab	Modifier un critère d'évaluation	criteres_evaluations.update	Permet de modifier un critère d'évaluation	criteres_evaluations	update	web	Lots et Évaluations	Critères	0	65	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-af2f-4aa2-8aa7-2f0beba9618e	Supprimer un critère d'évaluation	criteres_evaluations.delete	Permet de supprimer un critère d'évaluation	criteres_evaluations	delete	web	Lots et Évaluations	Critères	0	66	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-afb4-41ba-8354-9b5bd42b1357	Voir les proformas	proformas.read	Permet de consulter la liste des proformas	proformas	read	web	Pro-forma	Proformas	0	67	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b0d0-425e-84fe-32f712f535be	Voir les détails d'une proforma	proformas.view-details	Permet de consulter les détails complets d'une proforma	proformas	view-details	web	Pro-forma	Proformas	0	68	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b169-490f-82b7-9d38f16e93ab	Créer une proforma	proformas.create	Permet de créer une nouvelle proforma	proformas	create	web	Pro-forma	Proformas	0	69	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b1de-4f7d-a448-ae4fc5b0fcf7	Modifier une proforma	proformas.update	Permet de modifier une proforma existante	proformas	update	web	Pro-forma	Proformas	0	70	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b24d-41eb-90bd-1e64f5bc8ad9	Supprimer une proforma	proformas.delete	Permet de supprimer une proforma	proformas	delete	web	Pro-forma	Proformas	0	71	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b2bc-486f-8d31-7986d404b9d1	Créer une nouvelle version	proformas.create-version	Permet de créer une nouvelle version d'une proforma	proformas	create-version	web	Pro-forma	Proformas	0	72	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b330-4bd2-82cd-ae3936a0d537	Voir l'historique des proformas	proformas.view-history	Permet de consulter l'historique des versions des proformas	proformas	view-history	web	Pro-forma	Proformas	0	73	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b3bd-4777-afd5-bf64cc3a56c3	Voir les prestataires	prestataires.read	Permet de consulter la liste des prestataires	prestataires	read	web	Prestataires	Prestataires	0	74	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b444-4c1f-ab16-ea534a959da7	Voir les détails d'un prestataire	prestataires.view-details	Permet de consulter les détails complets d'un prestataire	prestataires	view-details	web	Prestataires	Prestataires	0	75	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b4c0-45e9-8cb2-5ec623a7aeb1	Créer un prestataire	prestataires.create	Permet de créer un nouveau prestataire	prestataires	create	web	Prestataires	Prestataires	0	76	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b572-4e4d-baeb-c162dd331aba	Modifier un prestataire	prestataires.update	Permet de modifier les informations d'un prestataire	prestataires	update	web	Prestataires	Prestataires	0	77	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b5e8-4b58-8500-fa1a6893542c	Supprimer un prestataire	prestataires.delete	Permet de supprimer un prestataire	prestataires	delete	web	Prestataires	Prestataires	0	78	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b653-463f-907b-7a4845f354e1	Activer/Désactiver un prestataire	prestataires.toggle-status	Permet d'activer ou désactiver un prestataire	prestataires	toggle-status	web	Prestataires	Prestataires	0	79	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b6c2-4d0f-8469-061015d096ce	Voir les informations bancaires	banques_prestataires.read	Permet de consulter les informations bancaires des prestataires	banques_prestataires	read	web	Prestataires	Banques	0	80	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b72c-4c3b-86a2-058462d4308f	Ajouter une banque	banques_prestataires.create	Permet d'ajouter une banque à un prestataire	banques_prestataires	create	web	Prestataires	Banques	0	81	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b79c-4972-a5ce-ce77f2c72720	Modifier une banque	banques_prestataires.update	Permet de modifier les informations bancaires	banques_prestataires	update	web	Prestataires	Banques	0	82	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b809-4abd-9dfd-1d3a2f2ba72e	Supprimer une banque	banques_prestataires.delete	Permet de supprimer une banque d'un prestataire	banques_prestataires	delete	web	Prestataires	Banques	0	83	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b877-4290-b900-f0efb5e4a911	Voir les capacités techniques	capacites_techniques.read	Permet de consulter les capacités techniques des prestataires	capacites_techniques	read	web	Prestataires	Capacités	0	84	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b8fd-41f4-9fff-de4d8e24d611	Gérer les capacités techniques	capacites_techniques.manage	Permet de gérer les capacités techniques d'un prestataire	capacites_techniques	manage	web	Prestataires	Capacités	0	85	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-b98a-47f1-b765-93239ad4d071	Voir les situations financières	situations_financieres.read	Permet de consulter les situations financières des prestataires	situations_financieres	read	web	Prestataires	Finances	0	86	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ba10-456a-bd5d-73d01a9f0ea4	Gérer les situations financières	situations_financieres.manage	Permet de gérer les situations financières d'un prestataire	situations_financieres	manage	web	Prestataires	Finances	0	87	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-ba7f-4936-8a9c-40d6e54d692a	Voir les attributions	attributions_lots.read	Permet de consulter les attributions de lots aux prestataires	attributions_lots	read	web	Attributions	Attributions	0	88	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bae9-41a2-8770-096bb3da6631	Voir les détails d'une attribution	attributions_lots.view-details	Permet de consulter les détails complets d'une attribution	attributions_lots	view-details	web	Attributions	Attributions	0	89	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bb55-4af1-a2d7-710291f8cd52	Attribuer un lot	attributions_lots.assign	Permet d'attribuer un lot à un prestataire	attributions_lots	assign	web	Attributions	Attributions	0	90	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bbc5-4656-ab6e-73d45c7d0019	Réattribuer un lot	attributions_lots.reassign	Permet de réattribuer un lot à un autre prestataire	attributions_lots	reassign	web	Attributions	Attributions	0	91	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bc32-47ae-b163-b233ddbbbd6b	Retirer une attribution	attributions_lots.withdraw	Permet de retirer une attribution de lot	attributions_lots	withdraw	web	Attributions	Attributions	0	92	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bca3-491c-940e-4379ae5f6e1e	Suspendre une attribution	attributions_lots.suspend	Permet de suspendre temporairement une attribution	attributions_lots	suspend	web	Attributions	Attributions	0	93	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bd6d-4169-b7a5-faed0d91eaa9	Reprendre une attribution	attributions_lots.resume	Permet de reprendre une attribution suspendue	attributions_lots	resume	web	Attributions	Attributions	0	94	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bdea-41e7-92a4-310c43fdc353	Voir l'historique des attributions	attributions_lots.view-history	Permet de consulter l'historique des attributions	attributions_lots	view-history	web	Attributions	Attributions	0	95	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-be5e-49ff-90d2-783b76e4c443	Voir les évaluations	evaluations_attributions.read	Permet de consulter les évaluations des prestataires	evaluations_attributions	read	web	Attributions	Évaluations	0	96	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-becb-4b5e-8858-4cad9f68513a	Évaluer un prestataire	evaluations_attributions.evaluate	Permet d'évaluer un prestataire sur un lot	evaluations_attributions	evaluate	web	Attributions	Évaluations	0	97	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bf34-42df-8e3b-6233a16d8701	Valider une évaluation	evaluations_attributions.validate	Permet de valider une évaluation	evaluations_attributions	validate	web	Attributions	Évaluations	0	98	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-bfa3-4c0f-8dbe-9e14b77e906f	Rejeter une évaluation	evaluations_attributions.reject	Permet de rejeter une évaluation	evaluations_attributions	reject	web	Attributions	Évaluations	0	99	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c025-4d98-b2ab-974e97fc4e12	Voir les factures	factures.read	Permet de consulter la liste des factures	factures	read	web	Facturation et Paiements	Factures	0	100	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c0a5-4eab-b68c-8bcd44f33601	Voir les détails d'une facture	factures.view-details	Permet de consulter les détails complets d'une facture	factures	view-details	web	Facturation et Paiements	Factures	0	101	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c131-4836-b1eb-d12de2b0c2ad	Créer une facture	factures.create	Permet de créer une nouvelle facture	factures	create	web	Facturation et Paiements	Factures	0	102	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c19e-4ef7-98e5-d093f04d1245	Modifier une facture	factures.update	Permet de modifier une facture existante	factures	update	web	Facturation et Paiements	Factures	0	103	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c20a-4685-967e-d027ff7eacbd	Valider une facture	factures.validate	Permet de valider une facture pour paiement	factures	validate	web	Facturation et Paiements	Factures	0	104	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c285-458c-84f7-a89e263b2303	Rejeter une facture	factures.reject	Permet de rejeter une facture	factures	reject	web	Facturation et Paiements	Factures	0	105	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c2fd-4ad3-a08d-f21e19104b14	Annuler une facture	factures.cancel	Permet d'annuler une facture	factures	cancel	web	Facturation et Paiements	Factures	0	106	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c367-435d-a786-fd3701a07d0d	Remettre en attente une facture	factures.pending	Permet de remettre en attente une facture rejetée	factures	pending	web	Facturation et Paiements	Factures	0	107	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c3d2-4f45-9d4b-75aa7ceea867	Dupliquer une facture	factures.duplicate	Permet de dupliquer une facture existante	factures	duplicate	web	Facturation et Paiements	Factures	0	108	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c43d-435b-99e6-b8586971229e	Supprimer une facture	factures.delete	Permet de supprimer définitivement une facture	factures	delete	web	Facturation et Paiements	Factures	0	109	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c4da-4556-90bc-63000696bd57	Voir les paiements	paiements.read	Permet de consulter la liste des paiements	paiements	read	web	Facturation et Paiements	Paiements	0	110	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c55d-4b94-968e-d239e22f030e	Voir les détails d'un paiement	paiements.view-details	Permet de consulter les détails complets d'un paiement	paiements	view-details	web	Facturation et Paiements	Paiements	0	111	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c5d2-42d8-962b-5d32826959e1	Créer un paiement	paiements.create	Permet d'initier un nouveau paiement	paiements	create	web	Facturation et Paiements	Paiements	0	112	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c663-4b64-a410-672ef2249d27	Traiter un paiement	paiements.process	Permet de traiter un paiement en attente	paiements	process	web	Facturation et Paiements	Paiements	0	113	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c6d5-4cb1-b93a-5773d285f1ad	Confirmer un paiement	paiements.confirm	Permet de confirmer l'exécution d'un paiement	paiements	confirm	web	Facturation et Paiements	Paiements	0	114	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c744-4374-900c-f93282be7f32	Rejeter un paiement	paiements.reject	Permet de rejeter un paiement	paiements	reject	web	Facturation et Paiements	Paiements	0	115	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c7b6-4862-a86c-03a595031b6a	Voir l'historique des paiements	paiements.view-history	Permet de consulter l'historique des paiements	paiements	view-history	web	Facturation et Paiements	Paiements	0	116	t	t	f	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c826-44cf-bc74-bb5df773afcf	Valider un paiement	paiements.validate	Permet de valider un paiement enregistré avant traitement	paiements	validate	web	Facturation et Paiements	Paiements	0	117	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c8a3-4c88-b7c0-dfcdfade7c6c	Remettre en attente un paiement	paiements.pending	Permet de remettre en attente un paiement rejeté	paiements	pending	web	Facturation et Paiements	Paiements	0	118	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c934-4350-bf69-36467b88e08a	Annuler un paiement	paiements.cancel	Permet d'annuler un paiement enregistré	paiements	cancel	web	Facturation et Paiements	Paiements	0	119	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b8-c9b1-48c3-827e-6d5e5c638b10	Supprimer un paiement	paiements.delete	Permet de supprimer définitivement un paiement	paiements	delete	web	Facturation et Paiements	Paiements	0	120	t	t	t	\N	\N	\N	\N	\N	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
\.


--
-- TOC entry 4946 (class 2606 OID 138647)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4948 (class 2606 OID 138649)
-- Name: permissions permissions_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_slug_unique UNIQUE (slug);


--
-- TOC entry 4950 (class 2606 OID 138633)
-- Name: permissions unique_permission_per_guard; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT unique_permission_per_guard UNIQUE (slug, guard_name);


--
-- TOC entry 4952 (class 2606 OID 138635)
-- Name: permissions unique_resource_action_guard; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT unique_resource_action_guard UNIQUE (resource, action, guard_name);


--
-- TOC entry 4937 (class 1259 OID 138626)
-- Name: idx_permissions_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_category ON public.permissions USING btree (category);


--
-- TOC entry 4938 (class 1259 OID 138630)
-- Name: idx_permissions_complete; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_complete ON public.permissions USING btree (resource, action, guard_name, is_active);


--
-- TOC entry 4939 (class 1259 OID 138625)
-- Name: idx_permissions_guard_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_guard_active ON public.permissions USING btree (guard_name, is_active);


--
-- TOC entry 4940 (class 1259 OID 138627)
-- Name: idx_permissions_module; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_module ON public.permissions USING btree (module);


--
-- TOC entry 4941 (class 1259 OID 138631)
-- Name: idx_permissions_module_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_module_category ON public.permissions USING btree (module, category, is_active);


--
-- TOC entry 4942 (class 1259 OID 138624)
-- Name: idx_permissions_resource_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_resource_action ON public.permissions USING btree (resource, action);


--
-- TOC entry 4943 (class 1259 OID 138628)
-- Name: idx_permissions_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_slug ON public.permissions USING btree (slug);


--
-- TOC entry 4944 (class 1259 OID 138629)
-- Name: idx_permissions_system_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permissions_system_active ON public.permissions USING btree (is_system, is_active);


--
-- TOC entry 4953 (class 2606 OID 138636)
-- Name: permissions permissions_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4954 (class 2606 OID 138641)
-- Name: permissions permissions_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


-- Completed on 2026-01-12 18:23:36

--
-- PostgreSQL database dump complete
--

\unrestrict hhgK6L96sqVL92fNkbl5C9EFUPWCfoVHQQXc4lxMqSg01LPvDOGyKZADXOcDOTh

