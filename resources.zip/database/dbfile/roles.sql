--
-- PostgreSQL database dump
--

\restrict 0EjB028SkKHSygXerBVYGTD4c7tajN25ADiMFKGyTM6aJkIJRA0WfyZ3eJMhWEY

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-12 18:23:10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 138502)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    level integer NOT NULL,
    is_system_role boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 5085 (class 0 OID 138502)
-- Dependencies: 221
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, slug, description, level, is_system_role, created_at, updated_at, deleted_at) FROM stdin;
a0d215b8-ce79-4617-9f38-2f39ca840673	Super Administrateur	super-administrateur	Accès complet et illimité à toutes les fonctionnalités du système. Ce rôle ne peut être ni modifié ni supprimé. Le Super Administrateur a tous les droits sans aucune exception et peut gérer tous les utilisateurs y compris les autres Super Administrateurs.	100	t	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b9-0422-446f-8019-5c61731ea3f0	Administrateur	administrateur	Accès étendu aux fonctionnalités d'administration. L'Administrateur peut gérer les utilisateurs, rôles et permissions mais ne peut PAS modifier, supprimer ou voir les informations des Super Administrateurs. Il peut uniquement gérer les utilisateurs de niveau inférieur au sien.	80	t	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b9-25cd-413d-8f77-d7a2108b3278	Manager	manager	Responsable de la gestion opérationnelle. Peut gérer les appels d'offres, lots, prestataires et évaluations. Accès limité aux fonctions d'administration.	60	f	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
a0d215b9-3e6d-412a-851c-a2ab9c480b58	Utilisateur	utilisateur	Utilisateur standard avec accès en lecture aux principales fonctionnalités. Peut consulter les appels d'offres, lots et prestataires.	20	f	2026-01-12 18:14:40	2026-01-12 18:14:40	\N
\.


--
-- TOC entry 4932 (class 2606 OID 138516)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4934 (class 2606 OID 138514)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4936 (class 2606 OID 138518)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


-- Completed on 2026-01-12 18:23:11

--
-- PostgreSQL database dump complete
--

\unrestrict 0EjB028SkKHSygXerBVYGTD4c7tajN25ADiMFKGyTM6aJkIJRA0WfyZ3eJMhWEY

