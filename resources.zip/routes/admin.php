<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;

/*
|--------------------------------------------------------------------------
| Routes du module Administration (Users, Roles, Permissions)
|--------------------------------------------------------------------------
|
| Ces routes gèrent la gestion des utilisateurs, des rôles et des permissions.
| À inclure dans routes/web.php avec:
| require __DIR__.'/admin.php';
|
*/

Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Routes Utilisateurs
    |--------------------------------------------------------------------------
    */
    Route::prefix('users')->name('users.')->group(function () {
        // Liste des utilisateurs supprimés
        Route::get('/trashed', [UserController::class, 'trashed'])->name('trashed');
        // Restaurer un utilisateur
        Route::post('/{id}/restore', [UserController::class, 'restore'])->name('restore');
        // Suppression définitive
        Route::delete('/{id}/force-delete', [UserController::class, 'forceDelete'])->name('force-delete');
        // Activer/Désactiver
        Route::patch('/{user}/activate', [UserController::class, 'activate'])->name('activate');
        Route::patch('/{user}/deactivate', [UserController::class, 'deactivate'])->name('deactivate');
        // Changer le rôle
        Route::patch('/{user}/change-role', [UserController::class, 'changeRole'])->name('change-role');
        // Réinitialiser le mot de passe
        Route::patch('/{user}/reset-password', [UserController::class, 'resetPassword'])->name('reset-password');
    });

    // Routes ressource CRUD pour les utilisateurs
    Route::resource('users', UserController::class);

    /*
    |--------------------------------------------------------------------------
    | Routes Rôles
    |--------------------------------------------------------------------------
    */
    Route::prefix('roles')->name('roles.')->group(function () {
        // Dupliquer un rôle
        Route::post('/{role}/duplicate', [RoleController::class, 'duplicate'])->name('duplicate');
        // Permissions d'un rôle
        Route::get('/{role}/permissions', [RoleController::class, 'permissions'])->name('permissions');
        Route::put('/{role}/permissions', [RoleController::class, 'updatePermissions'])->name('permissions.update');
        Route::post('/{role}/permissions/give', [RoleController::class, 'givePermission'])->name('permissions.give');
        Route::delete('/{role}/permissions/revoke', [RoleController::class, 'revokePermission'])->name('permissions.revoke');
        // Utilisateurs d'un rôle
        Route::get('/{role}/users', [RoleController::class, 'users'])->name('users');
    });

    // Routes ressource CRUD pour les rôles
    Route::resource('roles', RoleController::class);

    /*
    |--------------------------------------------------------------------------
    | Routes Permissions
    |--------------------------------------------------------------------------
    */
    Route::prefix('permissions')->name('permissions.')->group(function () {
        // Activer/Désactiver
        Route::patch('/{permission}/activate', [PermissionController::class, 'activate'])->name('activate');
        Route::patch('/{permission}/deactivate', [PermissionController::class, 'deactivate'])->name('deactivate');
        // Rôles ayant une permission
        Route::get('/{permission}/roles', [PermissionController::class, 'roles'])->name('roles');
        // Générer des permissions CRUD
        Route::post('/generate-crud', [PermissionController::class, 'generateCrud'])->name('generate-crud');
        // Vues groupées
        Route::get('/by-category', [PermissionController::class, 'byCategory'])->name('by-category');
        Route::get('/by-resource', [PermissionController::class, 'byResource'])->name('by-resource');
    });

    // Routes ressource CRUD pour les permissions
    Route::resource('permissions', PermissionController::class);
});


