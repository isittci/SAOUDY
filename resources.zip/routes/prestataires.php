<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PrestataireController;
use App\Http\Controllers\CapaciteTechniqueController;
use App\Http\Controllers\SituationFinanciereController;

/*
|--------------------------------------------------------------------------
| Routes Web
|--------------------------------------------------------------------------
*/

// Routes pour les Appels d'Offres
Route::middleware(['auth'])->prefix('prestataires')->name('prestataires.')->group(function () {
    Route::get('/', [PrestataireController::class, 'index'])->name('index');
    Route::get('/create', [PrestataireController::class, 'create'])->name('create');
    Route::post('/', [PrestataireController::class, 'store'])->name('store');
    Route::get('/{id}', [PrestataireController::class, 'show'])->name('show');
    Route::get('/{id}/edit', [PrestataireController::class, 'edit'])->name('edit');

    Route::put('/{id}', [PrestataireController::class, 'update'])->name('update');
    Route::delete('/{id}', [PrestataireController::class, 'destroy'])->name('destroy');

    // Actions spécifiques
    Route::post('/{id}/toggle-status', [PrestataireController::class, 'toggleStatus'])->name('toggle-status');
    Route::get('/{id}/statistiques', [PrestataireController::class, 'statistiques'])->name('statistiques');
    Route::post('/{id}/duplicate', [PrestataireController::class, 'duplicate'])->name('duplicate');

    Route::prefix('{id}/lots')->name('lots.')->group(function () {
        Route::get('/', [PrestataireController::class, 'lotsIndex'])->name('index');
        Route::get('/{lotId}/show', [PrestataireController::class, 'lotsShow'])->name('show');
        Route::get('/{lotId}/edit', [PrestataireController::class, 'lotsEdit'])->name('edit');
        Route::get('/{lotId}/retirer', [PrestataireController::class, 'retirer'])->name('retirer');
        Route::get('/{lotId}', [PrestataireController::class, 'lotsShow'])->name('show-lot');
    });
});


/*
|--------------------------------------------------------------------------
| Routes API
|--------------------------------------------------------------------------
*/

Route::prefix('api')->middleware(['auth:sanctum'])->group(function () {

    // API Appels d'Offres
    Route::prefix('prestataires')->name('api.prestataires.')->group(function () {
        Route::get('/', [PrestataireController::class, 'index'])->name('index');
        Route::get('/create', [PrestataireController::class, 'create'])->name('create');
        Route::post('/', [PrestataireController::class, 'store'])->name('store');
        Route::get('/{id}', [PrestataireController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [PrestataireController::class, 'edit'])->name('edit');
        Route::put('/{id}', [PrestataireController::class, 'update'])->name('update');
        Route::delete('/{id}', [PrestataireController::class, 'destroy'])->name('destroy');

        // Actions spécifiques
        Route::post('/{id}/toggle-status', [PrestataireController::class, 'toggleStatus'])->name('toggle-status');
        Route::get('/{id}/statistiques', [PrestataireController::class, 'statistiques'])->name('statistiques');
        Route::post('/{id}/duplicate', [PrestataireController::class, 'duplicate'])->name('duplicate');
    });
});



Route::prefix('prestataires/{prestataire}/capacites-techniques')
    ->name('prestataires.capacites-techniques.')
    ->middleware(['auth'])
    ->group(function () {

        // Liste des capacités techniques
        Route::get('/', [CapaciteTechniqueController::class, 'index'])->name('index');

        // Formulaire de création
        Route::get('/create', [CapaciteTechniqueController::class, 'create'])->name('create');

        // Enregistrer une capacité technique
        Route::post('/', [CapaciteTechniqueController::class, 'store'])->name('store');

        // Afficher une capacité technique
        Route::get('/{capacite}', [CapaciteTechniqueController::class, 'show'])->name('show');

        // Formulaire d'édition
        Route::get('/{capacite}/edit', [CapaciteTechniqueController::class, 'edit'])->name('edit');

        // Mettre à jour une capacité technique
        Route::put('/{capacite}', [CapaciteTechniqueController::class, 'update'])->name('update');

        // Supprimer une capacité technique
        Route::delete('/{capacite}', [CapaciteTechniqueController::class, 'destroy'])->name('destroy');
    });

/*
|--------------------------------------------------------------------------
| Routes Situations Financières (nested resource sous prestataires)
|--------------------------------------------------------------------------
*/
Route::prefix('prestataires/{prestataire}/situations-financieres')
    ->name('prestataires.situations-financieres.')
    ->middleware(['auth'])
    ->group(function () {

        // Liste des situations financières
        Route::get('/', [SituationFinanciereController::class, 'index'])->name('index');

        // Formulaire de création
        Route::get('/create', [SituationFinanciereController::class, 'create'])->name('create');

        // Enregistrer une situation financière
        Route::post('/', [SituationFinanciereController::class, 'store'])->name('store');

        // Afficher une situation financière
        Route::get('/{situation}', [SituationFinanciereController::class, 'show'])->name('show');

        // Formulaire d'édition
        Route::get('/{situation}/edit', [SituationFinanciereController::class, 'edit'])->name('edit');

        // Mettre à jour une situation financière
        Route::put('/{situation}', [SituationFinanciereController::class, 'update'])->name('update');

        // Supprimer une situation financière
        Route::delete('/{situation}', [SituationFinanciereController::class, 'destroy'])->name('destroy');

        // API: Données d'évolution pour graphique
        Route::get('/api/evolution', [SituationFinanciereController::class, 'evolution'])->name('evolution');
    });

