<?php

/*
|--------------------------------------------------------------------------
| Routes pour la gestion des documents des lots
|--------------------------------------------------------------------------
|
| À ajouter dans routes/web.php
|
*/

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DocumentController;

// Routes pour les documents des lots (nested resource)
Route::prefix('lots/{lotId}/documents')->name('lots.documents.')->middleware(['auth'])->group(function () {

    // Liste des documents
    Route::get('/', [DocumentController::class, 'index'])->name('index');

    // Formulaire de création
    Route::get('/create', [DocumentController::class, 'create'])->name('create');

    // Enregistrer un document
    Route::post('/', [DocumentController::class, 'store'])->name('store');

    // Upload multiple
    Route::post('/upload-multiple', [DocumentController::class, 'uploadMultiple'])->name('uploadMultiple');

    // Afficher un document
    Route::get('/{document}', [DocumentController::class, 'show'])->name('show');

    // Formulaire d'édition
    Route::get('/{document}/edit', [DocumentController::class, 'edit'])->name('edit');

    // Mettre à jour un document
    Route::put('/{document}', [DocumentController::class, 'update'])->name('update');

    // Supprimer un document
    Route::delete('/{document}', [DocumentController::class, 'destroy'])->name('destroy');

    // Télécharger un document
    Route::get('/{document}/download', [DocumentController::class, 'download'])->name('download');

    // Prévisualiser un document
    Route::get('/{document}/preview', [DocumentController::class, 'preview'])->name('preview');

    // Valider un document
    Route::patch('/{document}/valider', [DocumentController::class, 'valider'])->name('valider');

    // Invalider un document
    Route::patch('/{document}/invalider', [DocumentController::class, 'invalider'])->name('invalider');
});
