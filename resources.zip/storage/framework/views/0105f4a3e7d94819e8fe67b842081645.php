<?php $__env->startSection('title', 'Nouvelle Caractéristique'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('appels-offres.index')); ?>" class="text-white/80 hover:text-white transition-colors">Appels d'offres</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <a href="<?php echo e(route('appels-offres.show', $appelOffre->id_appel_offre)); ?>" class="text-white/80 hover:text-white transition-colors"><?php echo e($appelOffre->numero_appel_offre); ?></a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <a href="<?php echo e(route('caracteristiques-appels-offres.index', $appelOffre->id_appel_offre)); ?>" class="text-white/80 hover:text-white transition-colors">Caractéristiques</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Nouvelle</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo e(route('caracteristiques-appels-offres.index', $appelOffre->id_appel_offre)); ?>"
                        class="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200">
                        <i class="fas fa-arrow-left text-gray-600"></i>
                    </a>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800 flex items-center space-x-2">
                            <i class="fas fa-plus-circle text-green-500"></i>
                            <span>Nouvelle Caractéristique</span>
                        </h1>
                        <p class="text-gray-600 text-sm mt-1"><?php echo e($appelOffre->numero_appel_offre); ?> - <?php echo e($appelOffre->libelle_critere_appel_offre); ?></p>
                    </div>
                </div>

                <div class="flex items-center space-x-2">
                    <a href="<?php echo e(route('caracteristiques-appels-offres.index', $appelOffre->id_appel_offre)); ?>"
                        class="px-4 py-2 bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg transition-all duration-200 flex items-center space-x-2">
                        <i class="fas fa-times text-sm"></i>
                        <span class="text-sm font-medium hidden sm:inline">Annuler</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">

        <!-- Messages d'erreur -->
        <?php if($errors->any()): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg shadow-sm">
                <div class="flex items-start">
                    <i class="fas fa-exclamation-circle text-red-500 text-xl mr-3 mt-0.5"></i>
                    <div class="flex-1">
                        <h3 class="text-red-800 font-semibold mb-2">Erreurs de validation</h3>
                        <ul class="list-disc list-inside text-red-700 text-sm space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg shadow-sm animate-fadeIn">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-circle text-red-500 text-xl mr-3"></i>
                    <p class="text-red-700 font-medium"><?php echo e(session('error')); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Formulaire -->
        <form method="POST" action="<?php echo e(route('caracteristiques-appels-offres.store', $appelOffre->id_appel_offre)); ?>" class="max-w-5xl mx-auto">
            <?php echo csrf_field(); ?>

            <div class="space-y-6">

                <!-- Informations de l'AO (lecture seule) -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-indigo-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-bullhorn text-indigo-500 mr-2"></i>
                            Appel d'offres associé
                        </h2>
                    </div>

                    <div class="p-6">
                        <div class="p-4 bg-gradient-to-r from-indigo-50 to-white border border-indigo-200 rounded-lg">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center space-x-3 mb-2">
                                        <span class="inline-flex items-center px-3 py-1 rounded-lg text-sm font-bold bg-indigo-100 text-indigo-700">
                                            <?php echo e($appelOffre->numero_appel_offre); ?>

                                        </span>
                                        <span class="inline-flex items-center px-2 py-1 rounded text-xs font-semibold bg-blue-100 text-blue-700">
                                            <?php echo e($appelOffre->typeAppelOffre->code_type_appel_offre); ?>

                                        </span>
                                    </div>
                                    <h3 class="text-lg font-semibold text-gray-900 mb-2">
                                        <?php echo e($appelOffre->libelle_critere_appel_offre); ?>

                                    </h3>
                                    <p class="text-sm text-gray-600">
                                        <i class="fas fa-coins mr-1"></i>
                                        Montant global: <strong><?php echo e(number_format($appelOffre->montant_global_appel_offre, 0, ',', ' ')); ?> FCFA</strong>
                                    </p>
                                </div>
                                <a href="<?php echo e(route('appels-offres.show', $appelOffre->id_appel_offre)); ?>"
                                    target="_blank"
                                    class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                                    title="Voir l'appel d'offres">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Planning et Dates -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-blue-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-calendar-alt text-blue-500 mr-2"></i>
                            Planning et Dates
                        </h2>
                    </div>

                    <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Date de démarrage prévue -->
                        <div>
                            <label for="date_demarrage_prevue_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Date de démarrage prévue
                            </label>
                            <input type="date"
                                id="date_demarrage_prevue_caracteristique_appel_offre"
                                name="date_demarrage_prevue_caracteristique_appel_offre"
                                value="<?php echo e(old('date_demarrage_prevue_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent <?php $__errorArgs = ['date_demarrage_prevue_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['date_demarrage_prevue_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Durée estimée -->
                        <div>
                            <label for="duree_estimee_jours_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Durée estimée (en jours)
                            </label>
                            <input type="number"
                                id="duree_estimee_jours_caracteristique_appel_offre"
                                name="duree_estimee_jours_caracteristique_appel_offre"
                                min="1"
                                value="<?php echo e(old('duree_estimee_jours_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent <?php $__errorArgs = ['duree_estimee_jours_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: 90">
                            <?php $__errorArgs = ['duree_estimee_jours_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Date de livraison prévisionnelle -->
                        <div>
                            <label for="date_livraison_previsionnelle_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Date de livraison prévisionnelle
                            </label>
                            <input type="date"
                                id="date_livraison_previsionnelle_caracteristique_appel_offre"
                                name="date_livraison_previsionnelle_caracteristique_appel_offre"
                                value="<?php echo e(old('date_livraison_previsionnelle_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent <?php $__errorArgs = ['date_livraison_previsionnelle_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['date_livraison_previsionnelle_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Lieu d'exécution -->
                        <div>
                            <label for="lieu_execution_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Lieu d'exécution
                            </label>
                            <input type="text"
                                id="lieu_execution_caracteristique_appel_offre"
                                name="lieu_execution_caracteristique_appel_offre"
                                maxlength="255"
                                value="<?php echo e(old('lieu_execution_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent <?php $__errorArgs = ['lieu_execution_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: Abidjan, Plateau">
                            <?php $__errorArgs = ['lieu_execution_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Garanties et Pénalités -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-red-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-shield-alt text-red-500 mr-2"></i>
                            Garanties et Pénalités
                        </h2>
                    </div>

                    <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Pénalités de retard journalier -->
                        <div>
                            <label for="penalites_retard_journalier_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Pénalités de retard journalier (FCFA)
                            </label>
                            <input type="number"
                                id="penalites_retard_journalier_caracteristique_appel_offre"
                                name="penalites_retard_journalier_caracteristique_appel_offre"
                                min="0"
                                step="0.01"
                                value="<?php echo e(old('penalites_retard_journalier_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-400 focus:border-transparent <?php $__errorArgs = ['penalites_retard_journalier_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: 50000">
                            <?php $__errorArgs = ['penalites_retard_journalier_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <p class="text-xs text-gray-500 mt-1">
                                <i class="fas fa-info-circle mr-1"></i>
                                Montant appliqué par jour de retard
                            </p>
                        </div>

                        <!-- Montant de garantie -->
                        <div>
                            <label for="montant_garantie_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Montant de garantie (FCFA)
                            </label>
                            <input type="number"
                                id="montant_garantie_caracteristique_appel_offre"
                                name="montant_garantie_caracteristique_appel_offre"
                                min="0"
                                step="0.01"
                                value="<?php echo e(old('montant_garantie_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent <?php $__errorArgs = ['montant_garantie_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: 5000000">
                            <?php $__errorArgs = ['montant_garantie_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <p class="text-xs text-gray-500 mt-1">
                                <i class="fas fa-info-circle mr-1"></i>
                                Caution de bonne exécution (souvent 5-10% du marché)
                            </p>
                        </div>

                        <!-- Délai de garantie -->
                        <div>
                            <label for="delai_garantie_jours_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Délai de garantie (en jours)
                            </label>
                            <input type="number"
                                id="delai_garantie_jours_caracteristique_appel_offre"
                                name="delai_garantie_jours_caracteristique_appel_offre"
                                min="0"
                                value="<?php echo e(old('delai_garantie_jours_caracteristique_appel_offre')); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent <?php $__errorArgs = ['delai_garantie_jours_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: 365">
                            <?php $__errorArgs = ['delai_garantie_jours_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <p class="text-xs text-gray-500 mt-1">
                                <i class="fas fa-info-circle mr-1"></i>
                                Durée de garantie après réception
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Modalités et Documents -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-purple-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-file-contract text-purple-500 mr-2"></i>
                            Modalités et Documents
                        </h2>
                    </div>

                    <div class="p-6 space-y-6">
                        <!-- Conditions de paiement -->
                        <div>
                            <label for="conditions_paiement_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Conditions de paiement
                            </label>
                            <textarea
                                id="conditions_paiement_caracteristique_appel_offre"
                                name="conditions_paiement_caracteristique_appel_offre"
                                rows="3"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent <?php $__errorArgs = ['conditions_paiement_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: 30% à l'avance, 40% à mi-parcours, 30% à la livraison"><?php echo e(old('conditions_paiement_caracteristique_appel_offre')); ?></textarea>
                            <?php $__errorArgs = ['conditions_paiement_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Modalités d'exécution -->
                        <div>
                            <label for="modalites_execution_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Modalités d'exécution
                            </label>
                            <textarea
                                id="modalites_execution_caracteristique_appel_offre"
                                name="modalites_execution_caracteristique_appel_offre"
                                rows="4"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent <?php $__errorArgs = ['modalites_execution_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Exigences particulières pour l'exécution du marché..."><?php echo e(old('modalites_execution_caracteristique_appel_offre')); ?></textarea>
                            <?php $__errorArgs = ['modalites_execution_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Documents requis -->
                        <div>
                            <label for="documents_requis_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Documents requis
                            </label>
                            <textarea
                                id="documents_requis_caracteristique_appel_offre"
                                name="documents_requis_caracteristique_appel_offre"
                                rows="3"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent <?php $__errorArgs = ['documents_requis_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: Attestation fiscale, Certificat d'assurance, Caution bancaire..."><?php echo e(old('documents_requis_caracteristique_appel_offre')); ?></textarea>
                            <?php $__errorArgs = ['documents_requis_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Autres informations -->
                        <div>
                            <label for="autres_informations_caracteristique_appel_offre" class="block text-sm font-semibold text-gray-700 mb-2">
                                Autres informations
                            </label>
                            <textarea
                                id="autres_informations_caracteristique_appel_offre"
                                name="autres_informations_caracteristique_appel_offre"
                                rows="3"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent <?php $__errorArgs = ['autres_informations_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Informations complémentaires..."><?php echo e(old('autres_informations_caracteristique_appel_offre')); ?></textarea>
                            <?php $__errorArgs = ['autres_informations_caracteristique_appel_offre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Boutons d'action -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="p-6">
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <div class="text-sm text-gray-600">
                                <i class="fas fa-info-circle text-blue-500 mr-1"></i>
                                Tous les champs sont optionnels
                            </div>

                            <div class="flex items-center space-x-3 w-full sm:w-auto">
                                <?php
                                    $previous = url()->previous();
                                    $current = url()->current();
                                    $fallback = route('caracteristiques-appels-offres.index', $appelOffre->id_appel_offre);
                                ?>

                                <a href="<?php echo e($previous === $current ? $fallback : $previous); ?>"
                                    class="flex-1 sm:flex-none px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-medium text-center">
                                    Annuler
                                </a>
                                <button type="submit"
                                    class="flex-1 sm:flex-none px-6 py-2.5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-lg transition-all duration-200 font-medium shadow-md hover:shadow-lg flex items-center justify-center space-x-2">
                                    <i class="fas fa-save"></i>
                                    <span>Créer la caractéristique</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>

    <?php $__env->startPush('scripts'); ?>
        <script>
            // Validation date livraison > date démarrage
            document.getElementById('date_livraison_previsionnelle_caracteristique_appel_offre').addEventListener('change', function() {
                const dateDebut = document.getElementById('date_demarrage_prevue_caracteristique_appel_offre').value;
                const dateFin = this.value;

                if (dateDebut && dateFin && new Date(dateFin) <= new Date(dateDebut)) {
                    alert('La date de livraison doit être postérieure à la date de démarrage');
                    this.value = '';
                }
            });

            // Calcul automatique de la date de livraison basé sur la durée
            document.getElementById('duree_estimee_jours_caracteristique_appel_offre').addEventListener('change', function() {
                const dateDebut = document.getElementById('date_demarrage_prevue_caracteristique_appel_offre').value;
                const duree = parseInt(this.value);

                if (dateDebut && duree > 0) {
                    const date = new Date(dateDebut);
                    date.setDate(date.getDate() + duree);

                    const annee = date.getFullYear();
                    const mois = String(date.getMonth() + 1).padStart(2, '0');
                    const jour = String(date.getDate()).padStart(2, '0');

                    document.getElementById('date_livraison_previsionnelle_caracteristique_appel_offre').value = `${annee}-${mois}-${jour}`;
                }
            });
        </script>

        <style>
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .animate-fadeIn {
                animation: fadeIn 0.3s ease-out;
            }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/caracteristiques-appels-offres/create.blade.php ENDPATH**/ ?>