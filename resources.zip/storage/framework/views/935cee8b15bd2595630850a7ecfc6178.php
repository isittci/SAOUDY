<?php $__env->startSection('title', 'Modifier ' . $role->name); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('admin.roles.index')); ?>" class="text-white/80 hover:text-white transition-colors">Rôles</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <a href="<?php echo e(route('admin.roles.show', $role)); ?>" class="text-white/80 hover:text-white transition-colors"><?php echo e($role->name); ?></a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Modifier</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('admin.roles.show', $role)); ?>" class="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200">
                    <i class="fas fa-arrow-left text-gray-600"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold text-gray-800 flex items-center space-x-2">
                        <i class="fas fa-edit text-amber-500"></i>
                        <span>Modifier <?php echo e($role->name); ?></span>
                    </h1>
                    <p class="text-gray-600 mt-1">Niveau <?php echo e($role->level); ?> - <?php echo e($role->level_label); ?></p>
                </div>
            </div>
        </div>
    </div>

    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">
        <?php if($errors->any()): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg shadow-sm animate-fadeIn">
                <div class="flex items-start">
                    <i class="fas fa-exclamation-circle text-red-500 text-xl mr-3 mt-0.5"></i>
                    <div>
                        <p class="text-red-700 font-medium">Veuillez corriger les erreurs suivantes :</p>
                        <ul class="mt-2 text-sm text-red-600 list-disc list-inside">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update')): ?>
            <form action="<?php echo e(route('admin.roles.update', $role)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div class="lg:col-span-2 space-y-6">
                        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                            <div class="px-6 py-4 bg-gradient-to-r from-amber-50 to-white border-b border-gray-200">
                                <h2 class="text-lg font-bold text-gray-800 flex items-center">
                                    <i class="fas fa-info-circle text-amber-500 mr-2"></i>
                                    Informations générales
                                </h2>
                            </div>

                            <div class="p-6 space-y-5">
                                <div>
                                    <label for="name" class="block text-sm font-medium text-gray-700 mb-2">
                                        Nom du rôle <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" name="name" id="name" value="<?php echo e(old('name', $role->name)); ?>" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div>
                                    <label for="slug" class="block text-sm font-medium text-gray-700 mb-2">
                                        Slug <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" name="slug" id="slug" value="<?php echo e(old('slug', $role->slug)); ?>" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div>
                                    <label for="description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                    <textarea name="description" id="description" rows="4"
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $role->description)); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div>
                                    <label for="level" class="block text-sm font-medium text-gray-700 mb-2">
                                        Niveau hiérarchique <span class="text-red-500">*</span>
                                    </label>
                                    <div class="flex items-center space-x-4">
                                        <input type="number" name="level" id="level" value="<?php echo e(old('level', $role->level)); ?>" required min="1" max="99"
                                            class="w-32 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <span class="text-sm text-gray-500">De 1 à 99</span>
                                    </div>
                                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <?php if(isset($permissions) && $permissions->count() > 0): ?>
                            <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                                <div class="px-6 py-4 bg-gradient-to-r from-blue-50 to-white border-b border-gray-200">
                                    <div class="flex items-center justify-between">
                                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                                            <i class="fas fa-key text-blue-500 mr-2"></i>
                                            Permissions
                                        </h2>
                                        <div class="flex items-center space-x-2">
                                            <button type="button" onclick="selectAllPermissions()"
                                                class="px-3 py-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded-lg text-xs font-medium">
                                                <i class="fas fa-check-double mr-1"></i>Tout sélectionner
                                            </button>
                                            <button type="button" onclick="deselectAllPermissions()"
                                                class="px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded-lg text-xs font-medium">
                                                <i class="fas fa-times mr-1"></i>Tout désélectionner
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-6">
                                    <?php
                                        // GESTION UNIVERSELLE : Supporter toutes les structures de données
                                        // Si $permissions est déjà groupé (collection de collections), on l'aplatit
                                        $flatPermissions = $permissions;

                                        // Détecter si c'est déjà groupé (le premier élément est une collection)
                                        if ($permissions->first() instanceof \Illuminate\Support\Collection) {
                                            // Aplatir la collection groupée
                                            $flatPermissions = $permissions->flatten(1);
                                        }

                                        // Maintenant on groupe par catégorie sur la collection plate
                                        $groupedPermissions = $flatPermissions->groupBy('category');
                                    ?>

                                    <div class="space-y-4 max-h-96 overflow-y-auto">
                                        <?php $__currentLoopData = $groupedPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $categoryPermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border border-gray-200 rounded-lg overflow-hidden">
                                                <div class="px-4 py-3 bg-gray-50 flex items-center justify-between">
                                                    <h4 class="font-semibold text-gray-700 flex items-center">
                                                        <i class="fas fa-folder text-amber-500 mr-2"></i>
                                                        <?php echo e($category ?? 'Non catégorisé'); ?>

                                                    </h4>
                                                    <span class="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full">
                                                        <?php echo e($categoryPermissions->count()); ?> permissions
                                                    </span>
                                                </div>
                                                <div class="p-4 bg-white">
                                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                                        <?php $__currentLoopData = $categoryPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <label class="flex items-start p-2 rounded hover:bg-gray-50 cursor-pointer group border border-transparent hover:border-<?php echo e($permission->action_color); ?>-200">
                                                                <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                    class="permission-checkbox w-4 h-4 text-<?php echo e($permission->action_color); ?>-500 border-gray-300 rounded mt-0.5"
                                                                    <?php echo e(in_array($permission->id, old('permissions', $rolePermissions)) ? 'checked' : ''); ?>>
                                                                <div class="ml-2 flex-1">
                                                                    <span class="text-sm text-gray-700"><?php echo e($permission->name); ?></span>
                                                                    <div class="mt-1">
                                                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-<?php echo e($permission->action_color); ?>-100 text-<?php echo e($permission->action_color); ?>-800">
                                                                            <i class="fas <?php echo e($permission->action_icon); ?> text-xs mr-1"></i>
                                                                            <?php echo e($permission->action_label); ?>

                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </label>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="space-y-6">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles.update', 'roles.view-details'])): ?>
                            <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                                <div class="p-6 space-y-3">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update')): ?>
                                    <button type="submit"
                                        class="w-full px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-lg font-medium shadow-md flex items-center justify-center">
                                        <i class="fas fa-save mr-2"></i>
                                        Enregistrer les modifications
                                    </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view-details')): ?>
                                    <a href="<?php echo e(route('admin.roles.show', $role)); ?>"
                                        class="w-full px-6 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium flex items-center justify-center">
                                        <i class="fas fa-times mr-2"></i>
                                        Annuler
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="bg-amber-50 rounded-2xl p-4">
                            <div class="flex items-start">
                                <i class="fas fa-info-circle text-amber-500 text-lg mr-3 mt-0.5"></i>
                                <div class="text-sm text-amber-700">
                                    <p class="font-medium mb-1">💡 Conseil</p>
                                    <p>Pour une gestion plus avancée des permissions, utilisez la page dédiée de gestion des permissions du rôle.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </main>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function selectAllPermissions() {
                document.querySelectorAll('.permission-checkbox').forEach(cb => cb.checked = true);
            }

            function deselectAllPermissions() {
                document.querySelectorAll('.permission-checkbox').forEach(cb => cb.checked = false);
            }
        </script>

        <style>
            @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>