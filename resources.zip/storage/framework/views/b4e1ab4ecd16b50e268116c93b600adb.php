<?php $__env->startSection('title', 'Nouveau Prestataire'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('prestataires.index')); ?>" class="text-white/80 hover:text-white transition-colors">Prestataires</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Nouveau</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('prestataires.index')); ?>"
                    class="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200">
                    <i class="fas fa-arrow-left text-gray-600"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold text-gray-800 flex items-center">
                        <i class="fas fa-plus-circle text-orange-500 mr-2"></i>
                        Nouveau Prestataire
                    </h1>
                    <p class="text-gray-600 mt-1">Remplissez les informations du prestataire</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">

        <!-- Messages d'erreur -->
        <?php if($errors->any()): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg shadow-sm animate-fadeIn">
                <div class="flex items-start">
                    <i class="fas fa-exclamation-circle text-red-500 text-xl mr-3 mt-0.5"></i>
                    <div>
                        <p class="text-red-700 font-medium mb-2">Veuillez corriger les erreurs suivantes :</p>
                        <ul class="list-disc list-inside text-red-600 text-sm space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Message de validation d'étape (caché par défaut) -->
        <div id="validationAlert" class="hidden mb-6 bg-amber-50 border-l-4 border-amber-500 p-4 rounded-lg shadow-sm animate-fadeIn">
            <div class="flex items-start">
                <i class="fas fa-exclamation-triangle text-amber-500 text-xl mr-3 mt-0.5"></i>
                <div>
                    <p class="text-amber-700 font-medium mb-2">Champs obligatoires manquants :</p>
                    <ul id="validationList" class="list-disc list-inside text-amber-600 text-sm space-y-1">
                    </ul>
                </div>
            </div>
        </div>

        <form action="<?php echo e(route('prestataires.store')); ?>" method="POST" id="prestataireForm" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Étapes -->
            <div class="bg-white rounded-2xl shadow-lg p-4 mb-6">
                <div class="flex items-center justify-center flex-wrap gap-2">
                    <button type="button" onclick="goToStep(1)" id="step1Btn"
                        class="step-btn flex items-center space-x-2 px-4 py-2 rounded-lg bg-orange-500 text-white font-medium transition-all">
                        <span class="w-6 h-6 bg-white text-orange-500 rounded-full flex items-center justify-center text-sm font-bold">1</span>
                        <span class="hidden sm:inline">Informations générales</span>
                    </button>
                    <div class="w-8 h-0.5 bg-gray-300 hidden sm:block step-line" id="line1"></div>
                    <button type="button" onclick="goToStep(2)" id="step2Btn"
                        class="step-btn flex items-center space-x-2 px-4 py-2 rounded-lg bg-gray-100 text-gray-600 font-medium transition-all">
                        <span class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-sm font-bold">2</span>
                        <span class="hidden sm:inline">Contact & Adresse</span>
                    </button>
                    <div class="w-8 h-0.5 bg-gray-300 hidden sm:block step-line" id="line2"></div>
                    <button type="button" onclick="goToStep(3)" id="step3Btn"
                        class="step-btn flex items-center space-x-2 px-4 py-2 rounded-lg bg-gray-100 text-gray-600 font-medium transition-all">
                        <span class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-sm font-bold">3</span>
                        <span class="hidden sm:inline">Représentant légal</span>
                    </button>
                </div>

                <!-- Barre de progression -->
                <div class="mt-4 px-4">
                    <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div id="progressBar" class="h-full bg-gradient-to-r from-orange-400 to-orange-600 rounded-full transition-all duration-500" style="width: 33.33%"></div>
                    </div>
                    <p class="text-center text-sm text-gray-500 mt-2">Étape <span id="currentStepText">1</span> sur 3</p>
                </div>
            </div>

            <!-- Étape 1: Informations générales -->
            <div id="step1" class="step-content">
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-orange-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-building text-orange-500 mr-2"></i>
                            Informations générales
                        </h2>
                    </div>

                    <div class="p-6 space-y-6">
                        <!-- Raison sociale -->
                        <div>
                            <label for="raison_sociale_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                Raison sociale <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="raison_sociale_prestataire" id="raison_sociale_prestataire"
                                value="<?php echo e(old('raison_sociale_prestataire')); ?>" required maxlength="255"
                                data-label="Raison sociale"
                                class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all <?php $__errorArgs = ['raison_sociale_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: Société Générale de Construction SARL">
                            <?php $__errorArgs = ['raison_sociale_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Numéro d'identification -->
                        <div>
                            <label for="numero_identification_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                Numéro d'identification <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="numero_identification_prestataire" id="numero_identification_prestataire"
                                value="<?php echo e(old('numero_identification_prestataire')); ?>" required maxlength="25"
                                data-label="Numéro d'identification"
                                class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all <?php $__errorArgs = ['numero_identification_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: CI-ABJ-2024-001">
                            <?php $__errorArgs = ['numero_identification_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Numéro CC -->
                            <div>
                                <label for="numero_cc_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    N° Compte Contribuable <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="numero_cc_prestataire" id="numero_cc_prestataire"
                                    value="<?php echo e(old('numero_cc_prestataire')); ?>" required maxlength="50"
                                    data-label="N° Compte Contribuable"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all <?php $__errorArgs = ['numero_cc_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: CC-123456789">
                                <?php $__errorArgs = ['numero_cc_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Numéro RCCM -->
                            <div>
                                <label for="numero_rccm_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    N° RCCM <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="numero_rccm_prestataire" id="numero_rccm_prestataire"
                                    value="<?php echo e(old('numero_rccm_prestataire')); ?>" required maxlength="50"
                                    data-label="N° RCCM"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all <?php $__errorArgs = ['numero_rccm_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: RCCM-ABJ-2024-B-12345">
                                <?php $__errorArgs = ['numero_rccm_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Statut -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Statut</label>
                            <div class="flex items-center space-x-6">
                                <label class="inline-flex items-center cursor-pointer">
                                    <input type="radio" name="statut_prestataire" value="1"
                                        <?php echo e(old('statut_prestataire', '1') == '1' ? 'checked' : ''); ?>

                                        class="w-4 h-4 text-orange-500 border-gray-300 focus:ring-orange-400">
                                    <span class="ml-2 text-sm text-gray-700">Actif</span>
                                </label>
                                <label class="inline-flex items-center cursor-pointer">
                                    <input type="radio" name="statut_prestataire" value="0"
                                        <?php echo e(old('statut_prestataire') == '0' ? 'checked' : ''); ?>

                                        class="w-4 h-4 text-orange-500 border-gray-300 focus:ring-orange-400">
                                    <span class="ml-2 text-sm text-gray-700">Inactif</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end">
                        <button type="button" onclick="nextStep(1)"
                            class="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-all duration-200 font-medium flex items-center space-x-2">
                            <span>Suivant</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Étape 2: Contact & Adresse -->
            <div id="step2" class="step-content hidden">
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-blue-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-address-book text-blue-500 mr-2"></i>
                            Contact & Adresse
                        </h2>
                    </div>

                    <div class="p-6 space-y-6">
                        <!-- Email -->
                        <div>
                            <label for="email_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                Email <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-envelope text-gray-400"></i>
                                </div>
                                <input type="email" name="email_prestataire" id="email_prestataire"
                                    value="<?php echo e(old('email_prestataire')); ?>" required maxlength="255"
                                    data-label="Email"
                                    class="form-input w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all <?php $__errorArgs = ['email_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="contact@entreprise.com">
                            </div>
                            <?php $__errorArgs = ['email_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Téléphone principal -->
                            <div>
                                <label for="telephone_principal_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Téléphone principal <span class="text-red-500">*</span>
                                </label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-phone text-gray-400"></i>
                                    </div>
                                    <input type="tel" name="telephone_principal_prestataire" id="telephone_principal_prestataire"
                                        value="<?php echo e(old('telephone_principal_prestataire')); ?>" required maxlength="20"
                                        data-label="Téléphone principal"
                                        class="form-input w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all <?php $__errorArgs = ['telephone_principal_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="+225 07 XX XX XX XX">
                                </div>
                                <?php $__errorArgs = ['telephone_principal_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Téléphone secondaire -->
                            <div>
                                <label for="telephone_secondaire_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Téléphone secondaire
                                </label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-mobile-alt text-gray-400"></i>
                                    </div>
                                    <input type="tel" name="telephone_secondaire_prestataire" id="telephone_secondaire_prestataire"
                                        value="<?php echo e(old('telephone_secondaire_prestataire')); ?>" maxlength="20"
                                        class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                                        placeholder="+225 05 XX XX XX XX">
                                </div>
                            </div>
                        </div>

                        <!-- Adresse -->
                        <div>
                            <label for="adresse_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                Adresse <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <div class="absolute top-3 left-0 pl-3 pointer-events-none">
                                    <i class="fas fa-map-marker-alt text-gray-400"></i>
                                </div>
                                <textarea name="adresse_prestataire" id="adresse_prestataire" rows="2" required
                                    data-label="Adresse"
                                    class="form-input w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all resize-none <?php $__errorArgs = ['adresse_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Adresse complète du siège social"><?php echo e(old('adresse_prestataire')); ?></textarea>
                            </div>
                            <?php $__errorArgs = ['adresse_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Ville -->
                            <div>
                                <label for="ville_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Ville <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="ville_prestataire" id="ville_prestataire"
                                    value="<?php echo e(old('ville_prestataire')); ?>" required maxlength="50"
                                    data-label="Ville"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all <?php $__errorArgs = ['ville_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: Abidjan">
                                <?php $__errorArgs = ['ville_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Pays -->
                            <div>
                                <label for="pays_prestataire" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Pays <span class="text-red-500">*</span>
                                </label>
                                <select name="pays_prestataire" id="pays_prestataire" required
                                    data-label="Pays"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all <?php $__errorArgs = ['pays_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Sélectionner un pays</option>
                                    <option value="Côte d'Ivoire" <?php echo e(old('pays_prestataire') == "Côte d'Ivoire" ? 'selected' : ''); ?>>Côte d'Ivoire</option>
                                    <option value="Sénégal" <?php echo e(old('pays_prestataire') == "Sénégal" ? 'selected' : ''); ?>>Sénégal</option>
                                    <option value="Mali" <?php echo e(old('pays_prestataire') == "Mali" ? 'selected' : ''); ?>>Mali</option>
                                    <option value="Burkina Faso" <?php echo e(old('pays_prestataire') == "Burkina Faso" ? 'selected' : ''); ?>>Burkina Faso</option>
                                    <option value="Guinée" <?php echo e(old('pays_prestataire') == "Guinée" ? 'selected' : ''); ?>>Guinée</option>
                                    <option value="Togo" <?php echo e(old('pays_prestataire') == "Togo" ? 'selected' : ''); ?>>Togo</option>
                                    <option value="Bénin" <?php echo e(old('pays_prestataire') == "Bénin" ? 'selected' : ''); ?>>Bénin</option>
                                    <option value="Niger" <?php echo e(old('pays_prestataire') == "Niger" ? 'selected' : ''); ?>>Niger</option>
                                    <option value="Cameroun" <?php echo e(old('pays_prestataire') == "Cameroun" ? 'selected' : ''); ?>>Cameroun</option>
                                    <option value="Gabon" <?php echo e(old('pays_prestataire') == "Gabon" ? 'selected' : ''); ?>>Gabon</option>
                                    <option value="France" <?php echo e(old('pays_prestataire') == "France" ? 'selected' : ''); ?>>France</option>
                                    <option value="Autre" <?php echo e(old('pays_prestataire') == "Autre" ? 'selected' : ''); ?>>Autre</option>
                                </select>
                                <?php $__errorArgs = ['pays_prestataire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between">
                        <button type="button" onclick="prevStep(2)"
                            class="px-6 py-2.5 border border-gray-300 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200 font-medium flex items-center space-x-2">
                            <i class="fas fa-arrow-left"></i>
                            <span>Précédent</span>
                        </button>
                        <button type="button" onclick="nextStep(2)"
                            class="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-all duration-200 font-medium flex items-center space-x-2">
                            <span>Suivant</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Étape 3: Représentant légal -->
            <div id="step3" class="step-content hidden">
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 bg-gradient-to-r from-purple-50 to-white border-b border-gray-200">
                        <h2 class="text-lg font-bold text-gray-800 flex items-center">
                            <i class="fas fa-user-tie text-purple-500 mr-2"></i>
                            Représentant légal
                        </h2>
                    </div>

                    <div class="p-6 space-y-6">
                        <!-- Nom -->
                        <div>
                            <label for="nom" class="block text-sm font-semibold text-gray-700 mb-2">
                                Nom complet <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="nom" id="nom"
                                value="<?php echo e(old('nom')); ?>" required maxlength="100"
                                data-label="Nom complet"
                                class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: KOUASSI Jean-Marc">
                            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Email représentant -->
                            <div>
                                <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Email <span class="text-red-500">*</span>
                                </label>
                                <input type="email" name="email" id="email"
                                    value="<?php echo e(old('email')); ?>" required maxlength="255"
                                    data-label="Email du représentant"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="representant@email.com">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Contact -->
                            <div>
                                <label for="contact" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Contact <span class="text-red-500">*</span>
                                </label>
                                <input type="tel" name="contact" id="contact"
                                    value="<?php echo e(old('contact')); ?>" required maxlength="20"
                                    data-label="Contact du représentant"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="+225 XX XX XX XX XX">
                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Nationalité -->
                            <div>
                                <label for="nationalite" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Nationalité <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="nationalite" id="nationalite"
                                    value="<?php echo e(old('nationalite')); ?>" required maxlength="50"
                                    data-label="Nationalité"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['nationalite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: Ivoirienne">
                                <?php $__errorArgs = ['nationalite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Pays -->
                            <div>
                                <label for="pays" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Pays de résidence <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="pays" id="pays"
                                    value="<?php echo e(old('pays')); ?>" required maxlength="50"
                                    data-label="Pays de résidence"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['pays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: Côte d'Ivoire">
                                <?php $__errorArgs = ['pays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Adresse -->
                        <div>
                            <label for="adresse" class="block text-sm font-semibold text-gray-700 mb-2">
                                Adresse <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="adresse" id="adresse"
                                value="<?php echo e(old('adresse')); ?>" required maxlength="255"
                                data-label="Adresse du représentant"
                                class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Adresse du représentant légal">
                            <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Profession -->
                        <div>
                            <label for="profession" class="block text-sm font-semibold text-gray-700 mb-2">
                                Profession <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="profession" id="profession"
                                value="<?php echo e(old('profession')); ?>" required maxlength="100"
                                data-label="Profession"
                                class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ex: Gérant, Directeur Général">
                            <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Date de naissance -->
                            <div>
                                <label for="date_naissance" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Date de naissance <span class="text-red-500">*</span>
                                </label>
                                <input type="date" name="date_naissance" id="date_naissance"
                                    value="<?php echo e(old('date_naissance')); ?>" required
                                    data-label="Date de naissance"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Lieu de naissance -->
                            <div>
                                <label for="lieu_naissance" class="block text-sm font-semibold text-gray-700 mb-2">
                                    Lieu de naissance <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="lieu_naissance" id="lieu_naissance"
                                    value="<?php echo e(old('lieu_naissance')); ?>" required maxlength="100"
                                    data-label="Lieu de naissance"
                                    class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ex: Abidjan">
                                <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Pièce d'identité -->
                        <div class="p-4 bg-gray-50 rounded-lg space-y-4">
                            <h4 class="font-semibold text-gray-700 flex items-center">
                                <i class="fas fa-id-card text-gray-500 mr-2"></i>
                                Pièce d'identité
                            </h4>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <!-- Type pièce -->
                                <div>
                                    <label for="type_piece_identite" class="block text-sm font-semibold text-gray-700 mb-2">
                                        Type <span class="text-red-500">*</span>
                                    </label>
                                    <select name="type_piece_identite" id="type_piece_identite" required
                                        data-label="Type de pièce d'identité"
                                        class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['type_piece_identite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Sélectionner</option>
                                        <option value="CNI" <?php echo e(old('type_piece_identite') == "CNI" ? 'selected' : ''); ?>>CNI</option>
                                        <option value="Passeport" <?php echo e(old('type_piece_identite') == "Passeport" ? 'selected' : ''); ?>>Passeport</option>
                                        <option value="Carte Consulaire" <?php echo e(old('type_piece_identite') == "Carte Consulaire" ? 'selected' : ''); ?>>Carte Consulaire</option>
                                        <option value="Attestation" <?php echo e(old('type_piece_identite') == "Attestation" ? 'selected' : ''); ?>>Attestation d'identité</option>
                                    </select>
                                    <?php $__errorArgs = ['type_piece_identite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Numéro pièce -->
                                <div>
                                    <label for="numero_piece_identite" class="block text-sm font-semibold text-gray-700 mb-2">
                                        Numéro <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" name="numero_piece_identite" id="numero_piece_identite"
                                        value="<?php echo e(old('numero_piece_identite')); ?>" required maxlength="50"
                                        data-label="Numéro de pièce d'identité"
                                        class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['numero_piece_identite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Numéro de la pièce">
                                    <?php $__errorArgs = ['numero_piece_identite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <!-- Date délivrance -->
                                <div>
                                    <label for="date_delivrance" class="block text-sm font-semibold text-gray-700 mb-2">
                                        Date de délivrance <span class="text-red-500">*</span>
                                    </label>
                                    <input type="date" name="date_delivrance" id="date_delivrance"
                                        value="<?php echo e(old('date_delivrance')); ?>" required
                                        data-label="Date de délivrance"
                                        class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['date_delivrance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['date_delivrance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Lieu délivrance -->
                                <div>
                                    <label for="lieu_delivrance" class="block text-sm font-semibold text-gray-700 mb-2">
                                        Lieu de délivrance <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" name="lieu_delivrance" id="lieu_delivrance"
                                        value="<?php echo e(old('lieu_delivrance')); ?>" required maxlength="100"
                                        data-label="Lieu de délivrance"
                                        class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['lieu_delivrance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Ex: Abidjan">
                                    <?php $__errorArgs = ['lieu_delivrance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Date expiration -->
                                <div>
                                    <label for="date_expiration" class="block text-sm font-semibold text-gray-700 mb-2">
                                        Date d'expiration <span class="text-red-500">*</span>
                                    </label>
                                    <input type="date" name="date_expiration" id="date_expiration"
                                        value="<?php echo e(old('date_expiration')); ?>" required
                                        data-label="Date d'expiration"
                                        class="form-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all <?php $__errorArgs = ['date_expiration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['date_expiration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between">
                        <button type="button" onclick="prevStep(3)"
                            class="px-6 py-2.5 border border-gray-300 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200 font-medium flex items-center space-x-2">
                            <i class="fas fa-arrow-left"></i>
                            <span>Précédent</span>
                        </button>
                        <button type="submit" id="submitBtn"
                            class="px-8 py-2.5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-lg transition-all duration-200 font-medium flex items-center space-x-2 shadow-md hover:shadow-lg">
                            <i class="fas fa-save"></i>
                            <span>Enregistrer le prestataire</span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </main>

    <?php $__env->startPush('scripts'); ?>
        <script>
            let currentStep = 1;
            const totalSteps = 3;

            // Définition des champs obligatoires par étape
            const requiredFieldsByStep = {
                1: [
                    'raison_sociale_prestataire',
                    'numero_identification_prestataire',
                    'numero_cc_prestataire',
                    'numero_rccm_prestataire'
                ],
                2: [
                    'email_prestataire',
                    'telephone_principal_prestataire',
                    'adresse_prestataire',
                    'ville_prestataire',
                    'pays_prestataire'
                ],
                3: [
                    'nom',
                    'email',
                    'contact',
                    'nationalite',
                    'pays',
                    'adresse',
                    'profession',
                    'date_naissance',
                    'lieu_naissance',
                    'type_piece_identite',
                    'numero_piece_identite',
                    'date_delivrance',
                    'lieu_delivrance',
                    'date_expiration'
                ]
            };

            // Validation d'une étape
            function validateStep(step) {
                const fields = requiredFieldsByStep[step];
                const errors = [];

                fields.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        const value = field.value.trim();
                        const label = field.getAttribute('data-label') || fieldId;

                        // Vérifier si le champ est vide
                        if (!value) {
                            errors.push(label);
                            // Ajouter la classe d'erreur
                            field.classList.add('border-red-500', 'bg-red-50');
                            field.classList.remove('border-gray-300');
                        } else {
                            // Retirer la classe d'erreur
                            field.classList.remove('border-red-500', 'bg-red-50');
                            field.classList.add('border-gray-300');

                            // Validation spécifique pour les emails
                            if (field.type === 'email' && !isValidEmail(value)) {
                                errors.push(label + ' (format invalide)');
                                field.classList.add('border-red-500', 'bg-red-50');
                                field.classList.remove('border-gray-300');
                            }
                        }
                    }
                });

                return errors;
            }

            // Validation format email
            function isValidEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }

            // Afficher les erreurs de validation
            function showValidationErrors(errors) {
                const alertDiv = document.getElementById('validationAlert');
                const listUl = document.getElementById('validationList');

                listUl.innerHTML = '';
                errors.forEach(error => {
                    const li = document.createElement('li');
                    li.textContent = error;
                    listUl.appendChild(li);
                });

                alertDiv.classList.remove('hidden');

                // Scroll vers l'alerte
                alertDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });

                // Faire disparaître après 5 secondes
                setTimeout(() => {
                    alertDiv.classList.add('hidden');
                }, 5000);
            }

            // Cacher les erreurs de validation
            function hideValidationErrors() {
                document.getElementById('validationAlert').classList.add('hidden');
            }

            // Aller à l'étape suivante (avec validation)
            function nextStep(fromStep) {
                const errors = validateStep(fromStep);

                if (errors.length > 0) {
                    showValidationErrors(errors);
                    // Animer les champs avec erreur
                    shakeInvalidFields(fromStep);
                    return;
                }

                hideValidationErrors();
                showStep(fromStep + 1);
            }

            // Aller à l'étape précédente (sans validation)
            function prevStep(fromStep) {
                hideValidationErrors();
                showStep(fromStep - 1);
            }

            // Navigation directe vers une étape (avec validation des étapes précédentes)
            function goToStep(targetStep) {
                // Si on veut aller à une étape supérieure, valider toutes les étapes intermédiaires
                if (targetStep > currentStep) {
                    for (let step = currentStep; step < targetStep; step++) {
                        const errors = validateStep(step);
                        if (errors.length > 0) {
                            showValidationErrors(errors);
                            shakeInvalidFields(step);
                            showStep(step);
                            return;
                        }
                    }
                }

                hideValidationErrors();
                showStep(targetStep);
            }

            // Animer les champs invalides
            function shakeInvalidFields(step) {
                const fields = requiredFieldsByStep[step];
                fields.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field && field.classList.contains('border-red-500')) {
                        field.classList.add('animate-shake');
                        setTimeout(() => {
                            field.classList.remove('animate-shake');
                        }, 500);
                    }
                });
            }

            // Afficher une étape spécifique
            function showStep(step) {
                // Masquer toutes les étapes
                document.querySelectorAll('.step-content').forEach(el => el.classList.add('hidden'));

                // Afficher l'étape sélectionnée
                document.getElementById(`step${step}`).classList.remove('hidden');

                // Mettre à jour les boutons d'étape
                for (let i = 1; i <= totalSteps; i++) {
                    const btn = document.getElementById(`step${i}Btn`);
                    const numSpan = btn.querySelector('span:first-child');

                    if (i === step) {
                        // Étape active
                        btn.classList.remove('bg-gray-100', 'text-gray-600', 'bg-green-100', 'text-green-700');
                        btn.classList.add('bg-orange-500', 'text-white');
                        numSpan.classList.remove('bg-gray-300', 'text-white', 'bg-green-500');
                        numSpan.classList.add('bg-white', 'text-orange-500');
                    } else if (i < step) {
                        // Étape complétée
                        btn.classList.remove('bg-gray-100', 'text-gray-600', 'bg-orange-500', 'text-white');
                        btn.classList.add('bg-green-100', 'text-green-700');
                        numSpan.classList.remove('bg-gray-300', 'text-white', 'bg-white', 'text-orange-500');
                        numSpan.classList.add('bg-green-500', 'text-white');
                        numSpan.innerHTML = '<i class="fas fa-check text-xs"></i>';
                    } else {
                        // Étape future
                        btn.classList.remove('bg-orange-500', 'text-white', 'bg-green-100', 'text-green-700');
                        btn.classList.add('bg-gray-100', 'text-gray-600');
                        numSpan.classList.remove('bg-white', 'text-orange-500', 'bg-green-500');
                        numSpan.classList.add('bg-gray-300', 'text-white');
                        numSpan.innerHTML = i;
                    }
                }

                // Mettre à jour les lignes de connexion
                for (let i = 1; i < totalSteps; i++) {
                    const line = document.getElementById(`line${i}`);
                    if (line) {
                        if (i < step) {
                            line.classList.remove('bg-gray-300');
                            line.classList.add('bg-green-500');
                        } else {
                            line.classList.remove('bg-green-500');
                            line.classList.add('bg-gray-300');
                        }
                    }
                }

                // Mettre à jour la barre de progression
                const progress = (step / totalSteps) * 100;
                document.getElementById('progressBar').style.width = `${progress}%`;
                document.getElementById('currentStepText').textContent = step;

                currentStep = step;

                // Scroll vers le haut
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }

            // Validation en temps réel des champs
            document.querySelectorAll('.form-input').forEach(field => {
                field.addEventListener('input', function() {
                    if (this.value.trim()) {
                        this.classList.remove('border-red-500', 'bg-red-50');
                        this.classList.add('border-gray-300');
                    }
                });

                field.addEventListener('blur', function() {
                    if (this.hasAttribute('required') && !this.value.trim()) {
                        this.classList.add('border-red-500', 'bg-red-50');
                        this.classList.remove('border-gray-300');
                    }
                });
            });

            // Validation date expiration > date délivrance
            document.getElementById('date_expiration').addEventListener('change', function() {
                const dateDelivrance = document.getElementById('date_delivrance').value;
                const dateExpiration = this.value;

                if (dateDelivrance && dateExpiration && new Date(dateExpiration) <= new Date(dateDelivrance)) {
                    alert('La date d\'expiration doit être postérieure à la date de délivrance');
                    this.value = '';
                    this.classList.add('border-red-500', 'bg-red-50');
                }
            });

            // Validation date de naissance (doit être majeur)
            document.getElementById('date_naissance').addEventListener('change', function() {
                const dateNaissance = new Date(this.value);
                const today = new Date();
                const age = Math.floor((today - dateNaissance) / (365.25 * 24 * 60 * 60 * 1000));

                if (age < 18) {
                    alert('Le représentant légal doit être majeur (18 ans minimum)');
                    this.value = '';
                    this.classList.add('border-red-500', 'bg-red-50');
                }
            });

            // Soumission du formulaire avec validation finale
            document.getElementById('prestataireForm').addEventListener('submit', function(e) {
                // Valider toutes les étapes avant soumission
                for (let step = 1; step <= totalSteps; step++) {
                    const errors = validateStep(step);
                    if (errors.length > 0) {
                        e.preventDefault();
                        showValidationErrors(errors);
                        showStep(step);
                        return;
                    }
                }

                const submitBtn = document.getElementById('submitBtn');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Enregistrement en cours...';
            });

            // Initialisation au chargement
            document.addEventListener('DOMContentLoaded', function() {
                // Réinitialiser l'affichage des numéros d'étape
                for (let i = 1; i <= totalSteps; i++) {
                    const btn = document.getElementById(`step${i}Btn`);
                    const numSpan = btn.querySelector('span:first-child');
                    if (i > 1) {
                        numSpan.innerHTML = i;
                    }
                }
            });
        </script>

        <style>
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }

            .animate-fadeIn {
                animation: fadeIn 0.3s ease-out;
            }

            .animate-shake {
                animation: shake 0.5s ease-in-out;
            }

            .step-content {
                animation: fadeIn 0.3s ease-out;
            }

            /* Transition pour les champs invalides */
            .form-input {
                transition: all 0.3s ease;
            }

            .form-input.border-red-500 {
                box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            }

            /* Style pour les étapes complétées */
            .step-btn.bg-green-100 {
                position: relative;
            }

            .step-btn.bg-green-100::after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 50%;
                transform: translateX(-50%);
                width: 80%;
                height: 2px;
                background: linear-gradient(90deg, transparent, #22c55e, transparent);
            }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/prestataires/create.blade.php ENDPATH**/ ?>