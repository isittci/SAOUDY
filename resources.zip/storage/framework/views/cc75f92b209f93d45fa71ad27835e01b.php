<?php $__env->startSection('title', 'Corbeille - Utilisateurs'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="text-white/80 hover:text-white transition-colors">Utilisateurs</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Corbeille</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <!-- Titre et retour -->
                <div class="flex items-center space-x-4">
                    <a href="<?php echo e(route('admin.users.index')); ?>"
                        class="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200">
                        <i class="fas fa-arrow-left text-gray-600"></i>
                    </a>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800 flex items-center space-x-2">
                            <i class="fas fa-trash-alt text-red-500"></i>
                            <span>Corbeille - Utilisateurs Supprimés</span>
                        </h1>
                        <p class="text-gray-600 mt-1">Gérez les utilisateurs supprimés</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">

        <!-- Messages -->
        <?php if(session('success')): ?>
            <div class="mb-6 bg-green-50 border-l-4 border-green-500 p-4 rounded-lg shadow-sm animate-fadeIn">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-500 text-xl mr-3"></i>
                    <p class="text-green-700 font-medium"><?php echo e(session('success')); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg shadow-sm animate-fadeIn">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-circle text-red-500 text-xl mr-3"></i>
                    <p class="text-red-700 font-medium"><?php echo e(session('error')); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Info Alert -->
        <div class="mb-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg shadow-sm">
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle text-yellow-500 text-xl mr-3"></i>
                <p class="text-yellow-700">
                    Les utilisateurs dans la corbeille peuvent être restaurés ou supprimés définitivement.
                    <strong>Attention :</strong> la suppression définitive est irréversible.
                </p>
            </div>
        </div>

        <!-- Tableau -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <!-- En-tête du tableau -->
            <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-red-50 to-white">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-gray-800">
                        Utilisateurs supprimés (<span><?php echo e($users->total()); ?></span>)
                    </h2>
                </div>
            </div>

            <!-- Table responsive -->
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Utilisateur</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Contact</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Rôle</th>
                            <th class="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Supprimé le</th>
                            <th class="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Supprimé par</th>
                            <th class="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 bg-white">
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-red-50 transition-colors duration-150">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0">
                                            <span class="text-white font-semibold"><?php echo e(substr($user->nom_complet, 0, 1)); ?></span>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900"><?php echo e($user->nom_complet); ?></div>
                                            <div class="text-sm text-gray-500"><?php echo e($user->email); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?php echo e($user->telephone_principal ?? '-'); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if($user->role): ?>
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
                                            <?php echo e($user->role->name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400">Non assigné</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <div class="text-sm text-gray-900"><?php echo e($user->deleted_at->format('d/m/Y H:i')); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo e($user->deleted_at->diffForHumans()); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                    <?php if($user->deleter): ?>
                                        <?php echo e($user->deleter->nom_complet); ?>

                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <div class="flex items-center justify-center space-x-2">
                                        <form action="<?php echo e(route('admin.users.restore', $user->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit"
                                                class="px-3 py-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded-lg transition-all duration-200 text-sm font-medium">
                                                <i class="fas fa-undo mr-1"></i>Restaurer
                                            </button>
                                        </form>
                                        <button onclick="confirmForceDelete('<?php echo e($user->id); ?>', '<?php echo e($user->nom_complet); ?>')"
                                            class="px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded-lg transition-all duration-200 text-sm font-medium">
                                            <i class="fas fa-trash mr-1"></i>Supprimer
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center">
                                    <div class="flex flex-col items-center">
                                        <i class="fas fa-trash-alt text-gray-300 text-5xl mb-4"></i>
                                        <p class="text-gray-500 text-lg">La corbeille est vide</p>
                                        <a href="<?php echo e(route('admin.users.index')); ?>"
                                            class="mt-4 px-6 py-2.5 bg-gray-200 text-gray-700 hover:bg-gray-300 rounded-lg transition-all duration-200 font-medium">
                                            <i class="fas fa-arrow-left mr-2"></i>Retour aux utilisateurs
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if($users->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <?php echo e($users->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Modal Suppression définitive -->
    <div id="forceDeleteModal" class="hidden fixed inset-0 z-50 overflow-y-auto">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onclick="closeForceDeleteModal()"></div>

            <div class="relative bg-white rounded-2xl shadow-xl transform transition-all sm:max-w-md sm:w-full mx-auto">
                <div class="p-6 text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-2">Suppression définitive</h3>
                    <p class="text-gray-600 mb-2" id="forceDeleteMessage"></p>
                    <p class="text-red-600 font-semibold mb-6">Cette action est irréversible !</p>
                    <div class="flex justify-center space-x-3">
                        <button onclick="closeForceDeleteModal()"
                            class="px-4 py-2.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-medium">
                            Annuler
                        </button>
                        <button onclick="executeForceDelete()"
                            class="px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all duration-200 font-medium">
                            <i class="fas fa-trash mr-2"></i>Supprimer définitivement
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            let forceDeleteUserId = null;

            function confirmForceDelete(userId, userName) {
                forceDeleteUserId = userId;
                document.getElementById('forceDeleteMessage').textContent = `Êtes-vous sûr de vouloir supprimer définitivement l'utilisateur "${userName}" ?`;
                document.getElementById('forceDeleteModal').classList.remove('hidden');
            }

            function closeForceDeleteModal() {
                document.getElementById('forceDeleteModal').classList.add('hidden');
                forceDeleteUserId = null;
            }

            function executeForceDelete() {
                if (!forceDeleteUserId) return;

                fetch(`/admin/users/${forceDeleteUserId}/force-delete`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.message || 'Une erreur est survenue');
                        closeForceDeleteModal();
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Une erreur est survenue');
                    closeForceDeleteModal();
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeForceDeleteModal();
                }
            });
        </script>

        <style>
            @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/admin/users/trashed.blade.php ENDPATH**/ ?>