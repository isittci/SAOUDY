<?php $__env->startSection('title', 'Tableau de bord'); ?>
<?php $__env->startSection('breadcrumb', 'Tableau de bord'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/test.blade.php ENDPATH**/ ?>