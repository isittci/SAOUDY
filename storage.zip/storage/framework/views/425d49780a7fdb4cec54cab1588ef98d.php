<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?> | <?php echo $__env->yieldContent('page_title', 'Plateforme de gestion'); ?></title>

    
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', config('app.description', 'Plateforme de gestion sécurisée - Connectez-vous pour accéder à votre espace personnel et gérer vos services.')); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', config('app.keywords', 'gestion, plateforme, services, espace client, connexion, authentification')); ?>">
    <meta name="author" content="<?php echo e(config('app.author', config('app.name'))); ?>">

    
    <meta name="robots" content="<?php echo $__env->yieldContent('robots', 'index, follow'); ?>">
    <meta name="googlebot" content="<?php echo $__env->yieldContent('googlebot', 'index, follow'); ?>">

    
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">

    
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?php echo e(config('app.name')); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('og_title', config('app.name')); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('og_description', config('app.description', 'Plateforme de gestion sécurisée')); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', asset('images/og-image.png')); ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="<?php echo $__env->yieldContent('og_image_alt', config('app.name')); ?>">
    <meta property="og:locale" content="fr_FR">

    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="<?php echo $__env->yieldContent('twitter_site', config('app.twitter_handle', '')); ?>">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('twitter_title', config('app.name')); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('twitter_description', config('app.description', 'Plateforme de gestion sécurisée')); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('twitter_image', asset('images/twitter-card.png')); ?>">

    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon-16x16.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('site.webmanifest')); ?>">

    
    <meta name="theme-color" content="#22c55e">
    <meta name="msapplication-TileColor" content="#22c55e">
    <meta name="msapplication-navbutton-color" content="#22c55e">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="<?php echo e(config('app.name')); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">

    
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link rel="dns-prefetch" href="//cdnjs.cloudflare.com">

    
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "<?php echo e(config('app.name')); ?>",
        "description": "<?php echo $__env->yieldContent('meta_description', config('app.description', 'Plateforme de gestion sécurisée')); ?>",
        "url": "<?php echo e(config('app.url')); ?>",
        "applicationCategory": "BusinessApplication",
        "operatingSystem": "Web",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "XOF"
        },
        "author": {
            "@type": "Organization",
            "name": "<?php echo e(config('app.name')); ?>",
            "url": "<?php echo e(config('app.url')); ?>"
        }
    }
    </script>

    
    <?php if (! empty(trim($__env->yieldContent('breadcrumb_schema')))): ?>
        <?php echo $__env->yieldContent('breadcrumb_schema'); ?>
    <?php endif; ?>

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="min-h-screen bg-gradient-to-br from-yellow-300 via-green-400 to-green-500 flex items-center justify-center p-4">

    
    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-white px-4 py-2 rounded-lg shadow-lg z-50">
        Aller au contenu principal
    </a>

    <main id="main-content" class="w-full max-w-md bg-gradient-to-br from-yellow-200 to-green-300 rounded-3xl shadow-2xl p-8" role="main">
        
        <header class="flex justify-center mb-6">
            <div class="w-20 h-20 bg-blue-400 rounded-full flex items-center justify-center shadow-lg" role="img" aria-label="Logo <?php echo e(config('app.name')); ?>">
                <svg class="w-12 h-12 text-blue-900" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                </svg>
            </div>
        </header>

        
        <article>
            <?php echo $__env->yieldContent('content'); ?>
        </article>
    </main>

    
    <noscript>
        <div class="fixed inset-0 bg-yellow-100 flex items-center justify-center p-4 z-50">
            <div class="bg-white p-6 rounded-lg shadow-lg max-w-md text-center">
                <h2 class="text-xl font-bold text-gray-800 mb-2">JavaScript requis</h2>
                <p class="text-gray-600">Veuillez activer JavaScript dans votre navigateur pour utiliser cette application.</p>
            </div>
        </div>
    </noscript>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/layouts/auth.blade.php ENDPATH**/ ?>