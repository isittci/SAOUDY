<?php $__env->startSection('title', 'Modifier Attribution'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('attributions.index')); ?>" class="text-white/80 hover:text-white transition-colors">Attributions</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <a href="<?php echo e(route('attributions.show', $attribution->id_attribution)); ?>" class="text-white/80 hover:text-white transition-colors"><?php echo e($attribution->numero_attribution); ?></a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Modifier</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('attributions.show', $attribution->id_attribution)); ?>" class="p-2 hover:bg-gray-100 rounded-lg">
                    <i class="fas fa-arrow-left text-gray-600"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Modifier l'attribution</h1>
                    <p class="text-gray-600 mt-1"><?php echo e($attribution->numero_attribution); ?></p>
                </div>
            </div>
        </div>
    </div>

    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">

        <?php if($errors->any()): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
                <ul class="text-sm text-red-600 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-lg mb-6">
            <p class="text-yellow-800 text-sm">
                <i class="fas fa-info-circle mr-2"></i>
                Seules les informations non critiques peuvent être modifiées. Pour changer le prestataire ou la proforma, utilisez la fonction de réattribution.
            </p>
        </div>

        <form action="<?php echo e(route('attributions.update', $attribution->id_attribution)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="lg:col-span-2 space-y-6">

                    <!-- Dates -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-blue-50 to-white border-b">
                            <h2 class="text-lg font-bold text-gray-800"><i class="fas fa-calendar-alt text-blue-500 mr-2"></i>Planification</h2>
                        </div>
                        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Date début prévue</label>
                                <input type="date" name="date_debut_prevue"
                                    value="<?php echo e(old('date_debut_prevue', $attribution->date_debut_prevue ? $attribution->date_debut_prevue->format('Y-m-d') : '')); ?>"
                                    class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-400">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Date fin prévue</label>
                                <input type="date" name="date_fin_prevue"
                                    value="<?php echo e(old('date_fin_prevue', $attribution->date_fin_prevue ? $attribution->date_fin_prevue->format('Y-m-d') : '')); ?>"
                                    class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-400">
                            </div>
                        </div>
                    </div>

                    <!-- Pénalités -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-red-50 to-white border-b">
                            <h2 class="text-lg font-bold text-gray-800"><i class="fas fa-percent text-red-500 mr-2"></i>Pénalités</h2>
                        </div>
                        <div class="p-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Taux de pénalités (%)</label>
                                <input type="number" name="taux_penalites"
                                    value="<?php echo e(old('taux_penalites', $attribution->taux_penalites)); ?>"
                                    min="0" max="100" step="0.01"
                                    class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-red-400">
                                <p class="mt-1 text-xs text-gray-500">Pénalité par jour de retard</p>
                            </div>
                        </div>
                    </div>

                    <!-- Observations -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-gray-50 to-white border-b">
                            <h2 class="text-lg font-bold text-gray-800"><i class="fas fa-comment-alt text-gray-500 mr-2"></i>Notes</h2>
                        </div>
                        <div class="p-6 space-y-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Observations</label>
                                <textarea name="observations" rows="3"
                                    class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-gray-400"
                                    placeholder="Notes..."><?php echo e(old('observations', $attribution->observations)); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Conditions particulières</label>
                                <textarea name="conditions_particulieres" rows="4"
                                    class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-gray-400"
                                    placeholder="Conditions..."><?php echo e(old('conditions_particulieres', $attribution->conditions_particulieres)); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="space-y-6">
                    <!-- Résumé -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-orange-50 to-white border-b">
                            <h2 class="text-lg font-bold text-gray-800"><i class="fas fa-info-circle text-orange-500 mr-2"></i>Résumé</h2>
                        </div>
                        <div class="p-6 space-y-3 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-600">N° Attribution:</span>
                                <span class="font-medium text-gray-800"><?php echo e($attribution->numero_attribution); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Lot:</span>
                                <span class="font-medium text-gray-800"><?php echo e($attribution->lot->numero ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Prestataire:</span>
                                <span class="font-medium text-gray-800 truncate max-w-[150px]"><?php echo e($attribution->prestataire->raison_sociale_prestataire ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Proforma:</span>
                                <span class="font-medium text-gray-800"><?php echo e($attribution->proforma->numero_proforma ?? 'N/A'); ?></span>
                            </div>
                            <hr class="border-gray-200">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Statut:</span>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium <?php echo e($attribution->statut_badge_class); ?>">
                                    <?php echo e($attribution->statut_label); ?>

                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Avancement:</span>
                                <span class="font-medium text-gray-800"><?php echo e(number_format($attribution->pourcentage_avancement, 0)); ?>%</span>
                            </div>
                        </div>
                    </div>

                    <!-- Boutons -->
                    <div class="bg-white rounded-2xl shadow-lg p-6 space-y-3">
                        <button type="submit" class="w-full px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-medium rounded-lg shadow-md flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Enregistrer
                        </button>
                        <a href="<?php echo e(route('attributions.show', $attribution->id_attribution)); ?>" class="w-full px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium rounded-lg flex items-center justify-center">
                            <i class="fas fa-times mr-2"></i>Annuler
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/attributions/edit.blade.php ENDPATH**/ ?>