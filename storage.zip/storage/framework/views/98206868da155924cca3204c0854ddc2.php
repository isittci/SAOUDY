<?php $__env->startSection('title', 'Réattribuer le lot'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('attributions.index')); ?>" class="text-white/80 hover:text-white transition-colors">Attributions</a>
    <i class="fas fa-chevron-right text-white/50 text-xs mx-2"></i>
    <span class="text-white font-medium">Réattribution</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-gradient-to-r from-gray-50 to-white border-b border-gray-200 shadow-sm">
        <div class="px-3 sm:px-4 lg:px-6 py-4">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('attributions.show', $attribution->id_attribution)); ?>" class="p-2 hover:bg-gray-100 rounded-lg">
                    <i class="fas fa-arrow-left text-gray-600"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Réattribuer le Lot</h1>
                    <p class="text-gray-600 mt-1">Lot <?php echo e($attribution->lot->numero ?? 'N/A'); ?> - Ancienne: <?php echo e($attribution->numero_attribution); ?></p>
                </div>
            </div>
        </div>
    </div>

    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 lg:p-6">
        <?php if($errors->any()): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
                <ul class="text-sm text-red-600 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="mb-6 bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-lg">
            <p class="text-yellow-800 font-medium"><i class="fas fa-info-circle mr-2"></i>Réattribution en cours</p>
            <p class="text-sm text-yellow-700 mt-1">Le lot <strong><?php echo e($attribution->lot->numero ?? 'N/A'); ?></strong> sera réattribué. L'ancienne attribution devient historique.</p>
        </div>

        <form action="<?php echo e(route('attributions.reattribuer', $attribution->id_attribution)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="lg:col-span-2 space-y-6">
                    <!-- Motif -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-red-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-exclamation-circle text-red-500 mr-2"></i>Motif</h2></div>
                        <div class="p-6">
                            <textarea name="motif_reattribution" rows="3" required minlength="10" class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-red-400" placeholder="Pourquoi réattribuez-vous ce lot ?"><?php echo e(old('motif_reattribution')); ?></textarea>
                        </div>
                    </div>

                    <!-- Nouvelle attribution -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-green-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-user-plus text-green-500 mr-2"></i>Nouvelle attribution</h2></div>
                        <div class="p-6 space-y-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Nouveau prestataire *</label>
                                <select name="prestataire_id" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-400">
                                    <option value="">Sélectionnez...</option>
                                    <?php $__currentLoopData = $prestataires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id_prestataire); ?>" <?php echo e(old('prestataire_id') == $p->id_prestataire ? 'selected' : ''); ?>>
                                            <?php echo e($p->raison_sociale_prestataire); ?> <?php if($p->id_prestataire == $attribution->prestataire_id): ?>(Ancien)<?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Nouvelle proforma *</label>
                                <select name="proforma_id" id="proforma_id" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-400">
                                    <option value="">Sélectionnez...</option>
                                    <?php $__currentLoopData = $proformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pf->id_proforma); ?>" data-montant="<?php echo e($pf->montant_ttc ?? 0); ?>" <?php echo e(old('proforma_id') == $pf->id_proforma ? 'selected' : ''); ?>>
                                            <?php echo e($pf->numero_proforma); ?> - <?php echo e(number_format($pf->montant_ttc ?? 0, 0, ',', ' ')); ?> FCFA
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Dates -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-blue-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-calendar-alt text-blue-500 mr-2"></i>Planification</h2></div>
                        <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Date attribution *</label>
                                <input type="date" name="date_attribution" value="<?php echo e(old('date_attribution', date('Y-m-d'))); ?>" max="<?php echo e(date('Y-m-d')); ?>" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-400">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Date début *</label>
                                <input type="date" name="date_debut_prevue" value="<?php echo e(old('date_debut_prevue', date('Y-m-d'))); ?>" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-400">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Date fin *</label>
                                <input type="date" name="date_fin_prevue" value="<?php echo e(old('date_fin_prevue')); ?>" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-400">
                            </div>
                        </div>
                    </div>

                    <!-- Observations -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-gray-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-comment-alt text-gray-500 mr-2"></i>Observations</h2></div>
                        <div class="p-6">
                            <textarea name="observations" rows="3" class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-gray-400" placeholder="Notes..."><?php echo e(old('observations')); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="space-y-6">
                    <!-- Lot -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-indigo-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-box text-indigo-500 mr-2"></i>Lot</h2></div>
                        <div class="p-6 space-y-3">
                            <div><span class="text-sm text-gray-600">Numéro:</span> <span class="inline-flex items-center px-3 py-1 rounded-lg text-sm font-bold bg-indigo-100 text-indigo-700"><?php echo e($attribution->lot->numero ?? 'N/A'); ?></span></div>
                            <div><span class="text-sm text-gray-600">Libellé:</span> <p class="text-gray-800 font-medium"><?php echo e($attribution->lot->libelle ?? 'N/A'); ?></p></div>
                        </div>
                    </div>

                    <!-- Ancienne -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-gray-100 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-history text-gray-500 mr-2"></i>Ancienne</h2></div>
                        <div class="p-6 space-y-2 text-sm">
                            <div class="flex justify-between"><span class="text-gray-600">N°:</span><span class="font-medium"><?php echo e($attribution->numero_attribution); ?></span></div>
                            <div class="flex justify-between"><span class="text-gray-600">Version:</span><span class="font-medium">v<?php echo e($attribution->version_attribution); ?></span></div>
                            <div class="flex justify-between"><span class="text-gray-600">Prestataire:</span><span class="font-medium truncate max-w-[120px]"><?php echo e($attribution->prestataire->raison_sociale_prestataire ?? 'N/A'); ?></span></div>
                        </div>
                    </div>

                    <!-- Finances -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-green-50 to-white border-b"><h2 class="text-lg font-bold text-gray-800"><i class="fas fa-coins text-green-500 mr-2"></i>Finances</h2></div>
                        <div class="p-6 space-y-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Montant engagé</label>
                                <input type="number" name="montant_engage" id="montant_engage" value="<?php echo e(old('montant_engage', 0)); ?>" min="0" class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-400">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Taux pénalités (%)</label>
                                <input type="number" name="taux_penalites" value="<?php echo e(old('taux_penalites', $attribution->taux_penalites)); ?>" min="0" max="100" step="0.01" class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-400">
                            </div>
                        </div>
                    </div>

                    <!-- Boutons -->
                    <div class="bg-white rounded-2xl shadow-lg p-6 space-y-3">
                        <button type="submit" class="w-full px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-medium rounded-lg shadow-md flex items-center justify-center">
                            <i class="fas fa-redo mr-2"></i>Réattribuer
                        </button>
                        <a href="<?php echo e(route('attributions.show', $attribution->id_attribution)); ?>" class="w-full px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium rounded-lg flex items-center justify-center">
                            <i class="fas fa-times mr-2"></i>Annuler
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('proforma_id').addEventListener('change', function() {
    const opt = this.options[this.selectedIndex];
    if (opt.dataset.montant) document.getElementById('montant_engage').value = parseFloat(opt.dataset.montant);
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DATAS\DOCS\ISITTCI\call_of_tender_yamoussoukro\resources\views/attributions/reattribuer.blade.php ENDPATH**/ ?>